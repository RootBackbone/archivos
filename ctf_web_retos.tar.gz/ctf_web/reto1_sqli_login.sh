#!/bin/bash
# =============================================================================
# CTF MGP - RETO 1: SQL Injection Login (Básico)
# Puerto: 80  |  Path: /sqli-login/
# DB: sqli_db  |  Flag: Comciberdef{sqli_bypass_2026_ok}
# =============================================================================
set -e

VERDE="\e[32m"
AMARILLO="\e[33m"
ROJO="\e[31m"
RESET="\e[0m"

echo -e "${VERDE}[*] RETO 1 — SQLi Login: iniciando despliegue...${RESET}"

# -----------------------------------------------------------------------------
# 1. Dependencias
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Instalando dependencias...${RESET}"
apt-get update -qq
apt-get install -y -qq apache2 php libapache2-mod-php php-mysql mysql-server

systemctl enable apache2 mysql
systemctl start apache2 mysql

# -----------------------------------------------------------------------------
# 2. Base de datos sqli_db
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Creando base de datos sqli_db...${RESET}"
mysql -u root <<'SQLEOF'
CREATE DATABASE IF NOT EXISTS sqli_db CHARACTER SET utf8mb4;

CREATE USER IF NOT EXISTS 'ctf_sqli'@'localhost' IDENTIFIED BY 'Ctf$qliP4ss2026!';
GRANT SELECT ON sqli_db.* TO 'ctf_sqli'@'localhost';
FLUSH PRIVILEGES;

USE sqli_db;

DROP TABLE IF EXISTS users;
CREATE TABLE users (
    id       INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(60) NOT NULL,
    password VARCHAR(100) NOT NULL,
    role     VARCHAR(30) NOT NULL DEFAULT 'user'
);

-- Usuarios señuelo (ruido)
INSERT INTO users (username, password, role) VALUES
('operador1',  'Op3r@dor2026!',         'user'),
('operador2',  'Sup3rS3cur3Pass',       'user'),
('soporte',    'Sop0rt3MGP#2025',       'user'),
('logistica',  'L0g1st1c4Naval',        'user'),
-- Flag embebida en la contraseña del admin
('admin',      'Comciberdef{sqli_bypass_2026_ok}', 'admin');
SQLEOF
echo -e "${VERDE}    [OK] Base de datos sqli_db creada${RESET}"

# -----------------------------------------------------------------------------
# 3. Aplicación PHP vulnerable
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Desplegando aplicación web...${RESET}"
mkdir -p /var/www/html/sqli-login

# ---------- index.php (formulario de login con backend vulnerable) ----------
cat > /var/www/html/sqli-login/index.php <<'PHPEOF'
<?php
session_start();

$host = 'localhost';
$dbname = 'sqli_db';
$dbuser = 'ctf_sqli';
$dbpass = 'Ctf$qliP4ss2026!';

$conn = new mysqli($host, $dbuser, $dbpass, $dbname);
if ($conn->connect_error) {
    die("Error de conexión");
}

$error   = '';
$success = '';
$flag    = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = $_POST['username'] ?? '';
    $pass = $_POST['password'] ?? '';

    // ¡VULNERABLE! Concatenación directa — sin prepared statements
    $sql    = "SELECT * FROM users WHERE username = '$user' AND password = '$pass'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $row  = $result->fetch_assoc();
        $flag = $row['password'];
        $_SESSION['logged'] = true;
        $_SESSION['role']   = $row['role'];
        $_SESSION['user']   = $row['username'];
        header("Location: dashboard.php?flag=" . urlencode($flag));
        exit;
    } else {
        $error = 'Credenciales incorrectas. Acceso denegado.';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>COMCIBERDEF — Portal de Agentes</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:#0a0f1e;color:#c9d1d9;font-family:'Segoe UI',sans-serif;
       min-height:100vh;display:flex;align-items:center;justify-content:center}
  .card{background:#161b27;border:1px solid #1f6feb;border-radius:10px;
        padding:40px 36px;width:360px;box-shadow:0 8px 32px rgba(0,100,255,.15)}
  .logo{text-align:center;margin-bottom:28px}
  .logo h1{font-size:20px;color:#58a6ff;letter-spacing:2px;font-weight:700}
  .logo p{font-size:11px;color:#8b949e;margin-top:4px;letter-spacing:1px}
  label{font-size:12px;color:#8b949e;display:block;margin-bottom:6px;margin-top:16px}
  input[type=text],input[type=password]{
    width:100%;background:#0d1117;border:1px solid #30363d;border-radius:6px;
    padding:10px 12px;color:#e6edf3;font-size:14px;outline:none;transition:.2s}
  input:focus{border-color:#58a6ff}
  .btn{width:100%;margin-top:24px;padding:11px;background:#1f6feb;
       border:none;border-radius:6px;color:#fff;font-size:14px;
       font-weight:600;cursor:pointer;letter-spacing:.5px;transition:.2s}
  .btn:hover{background:#388bfd}
  .error{background:#3d1a1a;border:1px solid #f85149;color:#f85149;
         border-radius:6px;padding:10px 14px;font-size:13px;margin-top:16px}
  .footer{text-align:center;font-size:11px;color:#484f58;margin-top:20px}
</style>
</head>
<body>
<div class="card">
  <div class="logo">
    <h1>&#9632; COMCIBERDEF</h1>
    <p>PORTAL INTERNO — SOLO PERSONAL AUTORIZADO</p>
  </div>
  <form method="POST" action="">
    <label for="username">Usuario de Red</label>
    <input type="text" id="username" name="username"
           placeholder="ej. operador1" autocomplete="off" required>
    <label for="password">Contraseña</label>
    <input type="password" id="password" name="password"
           placeholder="••••••••" required>
    <button type="submit" class="btn">Iniciar Sesión</button>
    <?php if ($error): ?>
      <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
  </form>
  <div class="footer">Acceso registrado y auditado — MGP 2026</div>
</div>
</body>
</html>
PHPEOF

# ---------- dashboard.php (panel post-login, muestra la flag) ----------
cat > /var/www/html/sqli-login/dashboard.php <<'PHPEOF'
<?php
session_start();
$flag = $_GET['flag'] ?? '';
$user = $_SESSION['user'] ?? 'desconocido';
$role = $_SESSION['role'] ?? 'user';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>COMCIBERDEF — Panel Interno</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:#0a0f1e;color:#c9d1d9;font-family:'Segoe UI',sans-serif;
       min-height:100vh;display:flex;align-items:center;justify-content:center}
  .card{background:#161b27;border:1px solid #238636;border-radius:10px;
        padding:40px 36px;width:480px;text-align:center;
        box-shadow:0 8px 32px rgba(0,200,100,.1)}
  h2{color:#3fb950;margin-bottom:12px;font-size:22px}
  .user-info{font-size:13px;color:#8b949e;margin-bottom:24px}
  .flag-box{background:#0d1117;border:2px solid #3fb950;border-radius:8px;
            padding:18px 24px;font-family:monospace;font-size:16px;
            color:#3fb950;letter-spacing:1px;word-break:break-all;margin:20px 0}
  .label{font-size:11px;color:#484f58;text-transform:uppercase;
         letter-spacing:1px;margin-bottom:8px}
  .hint{font-size:12px;color:#8b949e;margin-top:20px;line-height:1.6}
  .back{display:inline-block;margin-top:24px;color:#58a6ff;
        font-size:13px;text-decoration:none}
</style>
</head>
<body>
<div class="card">
  <h2>&#10003; Acceso Concedido</h2>
  <div class="user-info">
    Usuario: <strong style="color:#e6edf3"><?= htmlspecialchars($user) ?></strong> &nbsp;|&nbsp;
    Rol: <strong style="color:#f0883e"><?= htmlspecialchars($role) ?></strong>
  </div>
  <div class="label">Flag del reto</div>
  <div class="flag-box"><?= htmlspecialchars($flag) ?></div>
  <div class="hint">
    Lograste bypassear la autenticación mediante SQL Injection.<br>
    El sistema no sanitizaba las entradas del formulario de login.
  </div>
  <a class="back" href="index.php">&#8592; Volver al login</a>
</div>
</body>
</html>
PHPEOF

# ---------- Permisos ----------
chown -R www-data:www-data /var/www/html/sqli-login
chmod -R 750 /var/www/html/sqli-login

echo -e "${VERDE}    [OK] Aplicación desplegada en /var/www/html/sqli-login/${RESET}"

# -----------------------------------------------------------------------------
# 4. Verificación rápida
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Verificando despliegue...${RESET}"
sleep 1

# Comprobar que la tabla tiene los datos
ROW_COUNT=$(mysql -u root -e "SELECT COUNT(*) FROM sqli_db.users;" -sN 2>/dev/null)
if [ "$ROW_COUNT" -eq 5 ]; then
    echo -e "${VERDE}    [OK] Tabla users tiene $ROW_COUNT filas${RESET}"
else
    echo -e "${ROJO}    [ERROR] Tabla users tiene $ROW_COUNT filas — revisar${RESET}"
fi

# Comprobar que el archivo index.php existe
if [ -f /var/www/html/sqli-login/index.php ]; then
    echo -e "${VERDE}    [OK] index.php presente${RESET}"
fi

echo ""
echo -e "${VERDE}============================================================${RESET}"
echo -e "${VERDE} RETO 1 - SQLi Login DESPLEGADO${RESET}"
echo -e "${VERDE}============================================================${RESET}"
echo -e " URL:      http://192.168.125.150/sqli-login/"
echo -e " Flag:     Comciberdef{sqli_bypass_2026_ok}"
echo -e " Payload1: ' OR 1=1 -- -       (obtiene primer usuario)"
echo -e " Payload2: ' OR 1=1 LIMIT 4,1 -- -  (obtiene admin + flag)"
echo -e "${VERDE}============================================================${RESET}"
