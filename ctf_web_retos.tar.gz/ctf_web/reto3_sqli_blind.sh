#!/bin/bash
# =============================================================================
# CTF MGP - RETO 3: SQL Injection Ciega Booleana (Intermedio)
# Puerto: 80  |  Path: /sqli-blind/
# DB: blind_db  |  Flag: la contraseña crackeada del moderador paco_admin
# Hash MD5 de "NavalCiber2026" = 7f8e2a9b3c1d4f6e0a5b7c8d9e0f1a2b
# Flag: Comciberdef{NavalCiber2026}
# =============================================================================
set -e

VERDE="\e[32m"
AMARILLO="\e[33m"
ROJO="\e[31m"
RESET="\e[0m"

echo -e "${VERDE}[*] RETO 3 — SQLi Ciega: iniciando despliegue...${RESET}"

# -----------------------------------------------------------------------------
# 1. Generar hash MD5 real de la contraseña objetivo
# -----------------------------------------------------------------------------
TARGET_PASS="NavalCiber2026"
MD5_HASH=$(echo -n "$TARGET_PASS" | md5sum | cut -d' ' -f1)
echo -e "${AMARILLO}[+] Hash MD5 de '$TARGET_PASS': $MD5_HASH${RESET}"

# -----------------------------------------------------------------------------
# 2. Base de datos blind_db
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Creando base de datos blind_db...${RESET}"
mysql -u root <<SQLEOF
CREATE DATABASE IF NOT EXISTS blind_db CHARACTER SET utf8mb4;

CREATE USER IF NOT EXISTS 'ctf_blind'@'localhost' IDENTIFIED BY 'Bl1ndCTF\$2026!';
GRANT SELECT ON blind_db.* TO 'ctf_blind'@'localhost';
FLUSH PRIVILEGES;

USE blind_db;

DROP TABLE IF EXISTS articles;
CREATE TABLE articles (
    id      INT AUTO_INCREMENT PRIMARY KEY,
    title   VARCHAR(200) NOT NULL,
    content TEXT,
    author  VARCHAR(80),
    visible TINYINT DEFAULT 1
);

INSERT INTO articles (title, content, author) VALUES
('Nuevo protocolo de seguridad perimetral',
 'El comando ha aprobado la implementación de nuevas medidas de seguridad en los accesos principales.',
 'Teniente Rodriguez'),
('Ejercicio UNITAS 2026 — Informe preliminar',
 'Las fuerzas navales conjuntas completaron con éxito la primera fase del ejercicio.',
 'Capitán Flores'),
('Actualización de sistemas de comunicaciones',
 'Se han renovado los equipos de comunicación satelital en las unidades de superficie.',
 'Teniente Comandante Vega'),
('Mantenimiento programado — Escuadrón 3',
 'El mantenimiento preventivo de las unidades del Escuadrón 3 se realizará el próximo mes.',
 'Mayor Castillo'),
('Informe de ciberseguridad Q1 2026',
 'Se detectaron y neutralizaron 47 intentos de intrusión en el trimestre.',
 'Coronel Saenz');

DROP TABLE IF EXISTS moderators;
CREATE TABLE moderators (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    username      VARCHAR(60) NOT NULL,
    password_hash VARCHAR(64) NOT NULL,
    clearance     VARCHAR(20) DEFAULT 'NIVEL-2'
);

-- Moderadores señuelo
INSERT INTO moderators (username, password_hash, clearance) VALUES
('mod_garcia',  MD5('Temporal123'),      'NIVEL-1'),
('mod_torres',  MD5('Sistemas456'),      'NIVEL-1'),
-- Objetivo del reto: crackear este hash
('paco_admin',  '$MD5_HASH',             'NIVEL-3'),
('mod_reyes',   MD5('Logistica789'),     'NIVEL-2');
SQLEOF
echo -e "${VERDE}    [OK] Base de datos blind_db creada — hash de paco_admin: $MD5_HASH${RESET}"

# -----------------------------------------------------------------------------
# 3. Wordlist local con la contraseña objetivo incluida
#    (para que el cracking sea posible sin Internet)
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Creando wordlist local en /home/rangeadmin/wordlist.txt...${RESET}"
mkdir -p /home/rangeadmin

cat > /home/rangeadmin/wordlist.txt <<WORDEOF
password
123456
admin
letmein
qwerty
military
naval
marina
peru2026
mgp2026
comciberdef
ciberdefensa
defensa2026
NavalCiber2026
Temporal123
Sistemas456
Logistica789
password123
abc123
iloveyou
monkey
dragon
master
superman
batman
trustno1
pass123
welcome
shadow
sunshine
princess
football
baseball
soccer
hockey
charlie
robert
thomas
hockey
rangers
donald
password1
iloveyou
dragon
master
hello
freedom
whatever
qazwsx
WORDEOF

chown rangeadmin:rangeadmin /home/rangeadmin/wordlist.txt
chmod 644 /home/rangeadmin/wordlist.txt
echo -e "${VERDE}    [OK] Wordlist creada con ${TARGET_PASS} incluido${RESET}"

# -----------------------------------------------------------------------------
# 4. Instalar herramientas de cracking en la VM (hashcat, john)
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Instalando herramientas de cracking...${RESET}"
apt-get install -y -qq hashcat john 2>/dev/null || true
echo -e "${VERDE}    [OK] hashcat y john disponibles${RESET}"

# -----------------------------------------------------------------------------
# 5. Aplicación PHP vulnerable a SQLi Ciega
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Desplegando aplicación sqli-blind...${RESET}"
mkdir -p /var/www/html/sqli-blind

# ---------- index.php — portal de artículos ----------
cat > /var/www/html/sqli-blind/index.php <<'PHPEOF'
<?php
$host   = 'localhost';
$dbname = 'blind_db';
$dbuser = 'ctf_blind';
$dbpass = 'Bl1ndCTF$2026!';

$conn = new mysqli($host, $dbuser, $dbpass, $dbname);
if ($conn->connect_error) { die("Error de sistema"); }

// Silenciar errores MySQL — parte del reto
mysqli_report(MYSQLI_REPORT_OFF);
$conn->query("SET SESSION sql_mode=''");

$id = $_GET['id'] ?? '';
$found    = false;
$articles = [];

// Obtener lista de artículos para mostrar en sidebar
$list_res = $conn->query("SELECT id, title FROM articles WHERE visible=1 ORDER BY id");
while ($row = $list_res->fetch_assoc()) {
    $articles[] = $row;
}

// *** VULNERABLE: $id se concatena directamente ***
// Sin mensajes de error — solo "Encontrado" / "No disponible"
if ($id !== '') {
    $sql    = "SELECT id, title, content, author FROM articles WHERE id = $id AND visible = 1";
    $result = @$conn->query($sql);  // @ suprime errores PHP
    if ($result && $result->num_rows > 0) {
        $found   = true;
        $article = $result->fetch_assoc();
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>COMCIBERDEF — Portal de Noticias Internas</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:#f7f8fa;font-family:'Segoe UI',sans-serif;color:#1a202c}
  header{background:#1a365d;color:#fff;padding:14px 32px;
         display:flex;align-items:center;gap:12px}
  header h1{font-size:18px;font-weight:700;letter-spacing:1px}
  header span{font-size:11px;color:#90cdf4;margin-left:auto}
  .layout{display:flex;min-height:calc(100vh - 52px)}
  .sidebar{width:260px;background:#fff;border-right:1px solid #e2e8f0;
           padding:20px;flex-shrink:0}
  .sidebar h3{font-size:12px;text-transform:uppercase;letter-spacing:1px;
              color:#718096;margin-bottom:12px}
  .sidebar a{display:block;padding:8px 10px;border-radius:6px;color:#2d3748;
             font-size:13px;text-decoration:none;margin-bottom:4px;transition:.15s}
  .sidebar a:hover{background:#ebf8ff;color:#2b6cb0}
  .sidebar a.active{background:#ebf8ff;color:#2b6cb0;font-weight:600}
  .main{flex:1;padding:32px}
  .card{background:#fff;border-radius:10px;padding:28px;
        box-shadow:0 1px 6px rgba(0,0,0,.06)}
  .found{border-left:4px solid #38a169}
  .not-found{border-left:4px solid #e53e3e;text-align:center;padding:40px}
  .found h2{font-size:20px;margin-bottom:8px;color:#1a365d}
  .found .meta{font-size:12px;color:#718096;margin-bottom:16px}
  .found .body{font-size:14px;line-height:1.7;color:#4a5568}
  .status{display:inline-block;padding:4px 10px;border-radius:20px;
          font-size:11px;font-weight:600;letter-spacing:.5px;margin-bottom:20px}
  .status.ok{background:#f0fff4;color:#276749;border:1px solid #9ae6b4}
  .status.err{background:#fff5f5;color:#c53030;border:1px solid #feb2b2}
  .not-found p{color:#718096;font-size:14px}
  .welcome{color:#718096;font-size:14px;line-height:1.7}
  .tip{background:#fffaf0;border:1px solid #f6ad55;border-radius:8px;
       padding:12px 16px;font-size:12px;color:#744210;margin-top:24px}
</style>
</head>
<body>
<header>
  <h1>&#128240; COMCIBERDEF — Portal de Noticias</h1>
  <span>CLASIFICADO: USO INTERNO</span>
</header>
<div class="layout">
  <div class="sidebar">
    <h3>Artículos disponibles</h3>
    <?php foreach ($articles as $a): ?>
      <a href="?id=<?= (int)$a['id'] ?>"
         class="<?= ($id == $a['id']) ? 'active' : '' ?>">
        <?= htmlspecialchars(substr($a['title'], 0, 38)) ?>
        <?= strlen($a['title']) > 38 ? '...' : '' ?>
      </a>
    <?php endforeach; ?>
  </div>

  <div class="main">
    <?php if ($id === ''): ?>
      <div class="card">
        <p class="welcome">
          Bienvenido al portal de noticias internas.<br><br>
          Selecciona un artículo del panel izquierdo o accede directamente
          mediante el parámetro <code>?id=</code> en la URL.<br><br>
          <em>Ejemplo: <code>?id=1</code></em>
        </p>
        <div class="tip">
          <strong>Nota para desarrolladores:</strong> El módulo de filtrado
          por ID está en revisión. Reportar anomalías al equipo de sistemas.
        </div>
      </div>

    <?php elseif ($found): ?>
      <div class="card found">
        <div class="status ok">&#10003; Artículo encontrado</div>
        <h2><?= htmlspecialchars($article['title']) ?></h2>
        <div class="meta">Autor: <?= htmlspecialchars($article['author']) ?></div>
        <div class="body"><?= htmlspecialchars($article['content']) ?></div>
      </div>

    <?php else: ?>
      <div class="card not-found">
        <div class="status err">Artículo no disponible</div>
        <p>El artículo con ID <strong><?= htmlspecialchars($id) ?></strong>
           no existe o no está disponible.<br>
           Selecciona otro artículo del menú lateral.</p>
      </div>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
PHPEOF

# Permisos
chown -R www-data:www-data /var/www/html/sqli-blind
chmod -R 750 /var/www/html/sqli-blind

echo -e "${VERDE}    [OK] Portal sqli-blind desplegado${RESET}"

# -----------------------------------------------------------------------------
# 6. Verificación — comprobar que la lógica booleana funciona
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Verificando lógica booleana...${RESET}"
sleep 1

# TRUE: id=1 AND 1=1 → "encontrado"
RES_TRUE=$(curl -s "http://localhost/sqli-blind/?id=1+AND+1%3D1" 2>/dev/null | grep -c "encontrado" || true)
# FALSE: id=1 AND 1=2 → "no disponible"
RES_FALSE=$(curl -s "http://localhost/sqli-blind/?id=1+AND+1%3D2" 2>/dev/null | grep -c "no disponible" || true)

if [ "$RES_TRUE" -gt 0 ] && [ "$RES_FALSE" -gt 0 ]; then
    echo -e "${VERDE}    [OK] Oráculo booleano funciona (TRUE/FALSE detectables)${RESET}"
else
    echo -e "${ROJO}    [WARN] Verificar respuestas booleanas manualmente${RESET}"
fi

# Verificar hash en BD
DB_HASH=$(mysql -u root -e "SELECT password_hash FROM blind_db.moderators WHERE username='paco_admin';" -sN 2>/dev/null)
echo -e "${VERDE}    [OK] Hash de paco_admin en BD: $DB_HASH${RESET}"

echo ""
echo -e "${VERDE}============================================================${RESET}"
echo -e "${VERDE} RETO 3 - SQLi Ciega DESPLEGADO${RESET}"
echo -e "${VERDE}============================================================${RESET}"
echo -e " URL:       http://192.168.125.150/sqli-blind/"
echo -e " Objetivo:  extraer hash de paco_admin y crackearlo"
echo -e " Hash MD5:  $MD5_HASH"
echo -e " Password:  $TARGET_PASS"
echo -e " Flag:      Comciberdef{NavalCiber2026}"
echo -e " Wordlist:  /home/rangeadmin/wordlist.txt"
echo -e " Cracking:  hashcat -m 0 -a 0 hash.txt /home/rangeadmin/wordlist.txt"
echo -e "            john --format=raw-md5 --wordlist=/home/rangeadmin/wordlist.txt hash.txt"
echo -e " SQLMap:    sqlmap -u 'http://192.168.125.150/sqli-blind/?id=1'"
echo -e "                   --technique=B --dbms=mysql --dump -T moderators -D blind_db"
echo -e "${VERDE}============================================================${RESET}"
