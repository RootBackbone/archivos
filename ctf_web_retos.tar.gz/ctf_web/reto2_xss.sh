#!/bin/bash
# =============================================================================
# CTF MGP - RETO 2: XSS Reflejado (Básico)
# Puerto: 8080  |  Path: /xss/
# Sin DB  |  Flag: Comciberdef{xss_reflected_2026_found}
# =============================================================================
set -e

VERDE="\e[32m"
AMARILLO="\e[33m"
ROJO="\e[31m"
RESET="\e[0m"

echo -e "${VERDE}[*] RETO 2 — XSS Reflejado: iniciando despliegue...${RESET}"

# -----------------------------------------------------------------------------
# 1. Dependencias (Apache ya instalado por reto1, añadimos soporte puerto 8080)
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Configurando Apache en puerto 8080...${RESET}"

# Añadir puerto 8080 si no existe
if ! grep -q "Listen 8080" /etc/apache2/ports.conf; then
    echo "Listen 8080" >> /etc/apache2/ports.conf
    echo -e "${VERDE}    [OK] Puerto 8080 añadido a ports.conf${RESET}"
fi

# -----------------------------------------------------------------------------
# 2. VirtualHost en puerto 8080
# -----------------------------------------------------------------------------
cat > /etc/apache2/sites-available/xss-ctf.conf <<'APACHEEOF'
<VirtualHost *:8080>
    ServerName 192.168.125.150
    DocumentRoot /var/www/html/xss
    DirectoryIndex index.php index.html

    <Directory /var/www/html/xss>
        Options -Indexes -FollowSymLinks
        AllowOverride None
        Require all granted
    </Directory>

    # Sin cabeceras de seguridad a propósito (vulnerable)
    # Header always set X-XSS-Protection "0"
    # Header always set Content-Security-Policy ""

    ErrorLog  ${APACHE_LOG_DIR}/xss_error.log
    CustomLog ${APACHE_LOG_DIR}/xss_access.log combined
</VirtualHost>
APACHEEOF

a2ensite xss-ctf.conf
a2enmod rewrite
systemctl reload apache2
echo -e "${VERDE}    [OK] VirtualHost 8080 activo${RESET}"

# -----------------------------------------------------------------------------
# 3. Aplicación PHP vulnerable a XSS
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Desplegando aplicación XSS...${RESET}"
mkdir -p /var/www/html/xss

# ---------- index.php — página de bienvenida de "Fast-Ship" ----------
cat > /var/www/html/xss/index.php <<'PHPEOF'
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Fast-Ship — Rastreo de Paquetes</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:#f4f6f8;font-family:'Segoe UI',sans-serif;color:#1a1a2e}
  header{background:#1a1a2e;color:#fff;padding:16px 40px;
         display:flex;align-items:center;gap:16px}
  header h1{font-size:22px;font-weight:700;letter-spacing:1px}
  header span{font-size:12px;color:#a0aec0}
  .hero{background:linear-gradient(135deg,#1a1a2e,#16213e);
        color:#fff;padding:60px 40px;text-align:center}
  .hero h2{font-size:32px;margin-bottom:12px}
  .hero p{color:#a0aec0;font-size:15px;margin-bottom:32px}
  .search-box{display:flex;gap:0;max-width:520px;margin:0 auto}
  .search-box input{flex:1;padding:14px 18px;border:none;border-radius:8px 0 0 8px;
                    font-size:15px;outline:none}
  .search-box button{padding:14px 24px;background:#e94560;color:#fff;
                     border:none;border-radius:0 8px 8px 0;cursor:pointer;
                     font-size:15px;font-weight:600}
  .search-box button:hover{background:#c73652}
  .features{display:flex;gap:24px;padding:48px 40px;justify-content:center;flex-wrap:wrap}
  .feat{background:#fff;border-radius:12px;padding:28px 24px;width:200px;text-align:center;
        box-shadow:0 2px 12px rgba(0,0,0,.07)}
  .feat .icon{font-size:32px;margin-bottom:12px}
  .feat h3{font-size:15px;margin-bottom:8px}
  .feat p{font-size:12px;color:#718096}
  footer{text-align:center;padding:20px;color:#a0aec0;font-size:12px;
         border-top:1px solid #e2e8f0}
</style>
</head>
<body>
<header>
  <div>
    <h1>&#128666; Fast-Ship</h1>
    <span>Logística & Rastreo Internacional</span>
  </div>
</header>

<div class="hero">
  <h2>Rastrea tu paquete en tiempo real</h2>
  <p>Ingresa el número o nombre de tu envío para ver su estado actualizado</p>
  <form class="search-box" action="search.php" method="GET">
    <input type="text" name="query" placeholder="Número de guía o remitente...">
    <button type="submit">Buscar</button>
  </form>
</div>

<div class="features">
  <div class="feat"><div class="icon">&#128205;</div><h3>Rastreo GPS</h3><p>Ubicación en tiempo real</p></div>
  <div class="feat"><div class="icon">&#128274;</div><h3>Seguro</h3><p>Paquetes asegurados</p></div>
  <div class="feat"><div class="icon">&#9201;</div><h3>24/7</h3><p>Soporte continuo</p></div>
</div>

<footer>Fast-Ship Logistics &copy; 2026 — Sistema de rastreo v2.1.4</footer>
</body>
</html>
PHPEOF

# ---------- search.php — VULNERABLE a XSS reflejado ----------
# La flag está pre-cargada en una cookie de sesión simulada
# El participante debe robarla ejecutando JS en el parámetro ?query=
cat > /var/www/html/xss/search.php <<'PHPEOF'
<?php
// Simulamos una cookie de sesión con la flag
// El participante debe ejecutar: <script>alert(document.cookie)</script>
// o variantes para visualizarla
$flag_cookie = "session_flag=Comciberdef{xss_reflected_2026_found}";
header("Set-Cookie: $flag_cookie; path=/");

$query = $_GET['query'] ?? '';
// *** VULNERABLE: echo sin escapado — XSS reflejado directo ***
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Fast-Ship — Resultados de búsqueda</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:#f4f6f8;font-family:'Segoe UI',sans-serif;color:#1a1a2e}
  header{background:#1a1a2e;color:#fff;padding:16px 40px;
         display:flex;align-items:center;justify-content:space-between}
  header h1{font-size:20px;font-weight:700;letter-spacing:1px}
  .container{max-width:760px;margin:40px auto;padding:0 24px}
  .result-box{background:#fff;border-radius:12px;padding:32px;
              box-shadow:0 2px 12px rgba(0,0,0,.07)}
  .result-box h2{font-size:18px;margin-bottom:8px;color:#2d3748}
  .query-echo{background:#edf2f7;border-left:4px solid #e94560;
              padding:14px 18px;border-radius:0 8px 8px 0;
              font-size:15px;margin:16px 0;color:#4a5568}
  .no-result{color:#718096;font-size:14px;margin-top:16px}
  .back{display:inline-block;margin-top:24px;color:#e94560;
        font-size:14px;text-decoration:none}
  .hint{background:#fffbeb;border:1px solid #f6e05e;border-radius:8px;
        padding:12px 16px;font-size:12px;color:#744210;margin-top:20px}
</style>
</head>
<body>
<header>
  <h1>&#128666; Fast-Ship</h1>
  <a href="index.php" style="color:#a0aec0;font-size:13px;text-decoration:none">&#8592; Inicio</a>
</header>
<div class="container">
  <div class="result-box">
    <h2>Resultados de búsqueda</h2>
    <p style="font-size:13px;color:#718096">Buscaste:</p>
    <div class="query-echo">
      <!-- VULNERABLE: el input se refleja sin sanitizar -->
      <?php echo $query; ?>
    </div>
    <div class="no-result">
      No se encontraron resultados para el término ingresado.<br>
      Verifica el número de guía e intenta nuevamente.
    </div>
    <div class="hint">
      <strong>Tip:</strong> Los números de guía tienen el formato FS-XXXXXXXX (8 dígitos).
    </div>
    <a class="back" href="index.php">&#8592; Nueva búsqueda</a>
  </div>
</div>
</body>
</html>
PHPEOF

# Permisos
chown -R www-data:www-data /var/www/html/xss
chmod -R 750 /var/www/html/xss

echo -e "${VERDE}    [OK] Aplicación XSS desplegada${RESET}"

# -----------------------------------------------------------------------------
# 4. Verificación
# -----------------------------------------------------------------------------
echo -e "${AMARILLO}[+] Verificando despliegue...${RESET}"
sleep 1

HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8080/xss/index.php 2>/dev/null || echo "000")
if [ "$HTTP_CODE" = "200" ]; then
    echo -e "${VERDE}    [OK] Puerto 8080 responde HTTP 200${RESET}"
else
    echo -e "${ROJO}    [WARN] Puerto 8080 responde: $HTTP_CODE — verificar Apache${RESET}"
fi

echo ""
echo -e "${VERDE}============================================================${RESET}"
echo -e "${VERDE} RETO 2 - XSS Reflejado DESPLEGADO${RESET}"
echo -e "${VERDE}============================================================${RESET}"
echo -e " URL:     http://192.168.125.150:8080/xss/"
echo -e " Flag:    Comciberdef{xss_reflected_2026_found}"
echo -e " Payload: <script>alert(document.cookie)</script>"
echo -e "          via ?query= en search.php"
echo -e "${VERDE}============================================================${RESET}"
